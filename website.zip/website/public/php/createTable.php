<?php
include 'credentials.php';
$servername = $credentials['host'];
$username = $credentials['username'];
$password = $credentials['password'];
$dbname = $credentials['dbname'];

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "
CREATE TABLE IF NOT EXISTS `website`.`user` (
 `user_id` VARCHAR(255) NOT NULL,
 `user_name` VARCHAR(255) NULL,
 `user_icon_url` VARCHAR(255) NULL,
 `secuity_question_id` int(10) NOT NULL,
 `secuity_question_answer` VARCHAR(255) NOT NULL,
 `email` VARCHAR(255) NOT NULL UNIQUE,
 `password` VARCHAR(255) NOT NULL,
 `status` VARCHAR(255) DEFAULT 'inactive',
 `varify_token` VARCHAR(255) NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 `last_login` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (`user_id`)) ENGINE = InnoDB;
";
 
$sql2 = "
CREATE TABLE IF NOT EXISTS `website`.`admin` (
 `admin_id` VARCHAR(255) NOT NULL,
 `role_id` INT(255) NOT NULL ,
 `user_name` VARCHAR(255) NOT NULL,
 `email` VARCHAR(255) NOT NULL UNIQUE,
 `password` VARCHAR(255) NOT NULL,
 `status` VARCHAR(255) DEFAULT 'active',
 `varify_token` VARCHAR(255) NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 `last_login` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (`admin_id`)) ENGINE = InnoDB;
";
 
$sql3 = "
CREATE TABLE IF NOT EXISTS `website`.`admin_role` (
 `role_id` INT(255) NOT NULL AUTO_INCREMENT,
 `role_name` VARCHAR(255) NOT NULL,
 `description` VARCHAR(255) NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`role_id`))
 ENGINE = InnoDB;
";
 
$sql4 = "
CREATE TABLE IF NOT EXISTS `website`.`product` (
 `product_id` VARCHAR(255) NOT NULL,
 `product_name` VARCHAR(255) NOT NULL,
 `product_price` FLOAT NOT NULL,
 `product_url` VARCHAR(255) NOT NULL,
 `product_display_image_url` VARCHAR(255) NOT NULL,
 `product_description` VARCHAR(255) NOT NULL,
 `product_detail` VARCHAR(255) NOT NULL,
 `categories_id` VARCHAR(255) NOT NULL,
 `stock_level` INT(255) NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 `update_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (`product_id`)) ENGINE = InnoDB;
";
 
$sql5 = "
CREATE TABLE IF NOT EXISTS `website`.`categories` (
 `categories_id` VARCHAR(255) NOT NULL,
 `categories_name` VARCHAR(255) NOT NULL,
 `categories_description` VARCHAR(255) NOT NULL,
 `parent_categories_id` INT(255) DEFAULT -1,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 `update_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (`categories_id`)) ENGINE = InnoDB;
";
 
$sql6 = "
CREATE TABLE IF NOT EXISTS `website`.`discount` (
 `discount_id` INT(255) NOT NULL AUTO_INCREMENT,
 `discount_name` VARCHAR(255) NOT NULL,
 `discount_type` VARCHAR(255) NOT NULL,
 `discount_among` INT(255) NOT NULL,
 `product_id` INT(255) NOT NULL,
 `expiration_date` TIMESTAMP NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`discount_id`)) ENGINE = InnoDB;
";
 
$sql7 = "
CREATE TABLE IF NOT EXISTS `website`.`review` (
 `review_id` INT(255) NOT NULL AUTO_INCREMENT,
 `product_id` VARCHAR(255) NOT NULL,
 `user_id` INT(255) NOT NULL,
 `user_icon_url` VARCHAR(255) NULL,
 `rating` INT(255) DEFAULT -1 NOT NULL,
 `author` VARCHAR(255) NOT NULL,
 `content` VARCHAR(255) NOT NULL,
 `status` VARCHAR(255) NOT NULL,
 `modify_count` INT(255) DEFAULT 0,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 `update_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (`review_id`)) ENGINE = InnoDB;
";
 
$sql8 = "
CREATE TABLE IF NOT EXISTS `website`.`order_admin_management` (
 `manage_id` INT(255) NOT NULL AUTO_INCREMENT,
 `admin_id` VARCHAR(255) NOT NULL,
 `order_id` VARCHAR(255) NOT NULL,
 `action` ENUM('create', 'update', 'delete') NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`manage_id`)) ENGINE = InnoDB;
";
 
$sql9 = "
CREATE TABLE IF NOT EXISTS `website`.`security_questions` (
 `question_id` INT(255) NOT NULL AUTO_INCREMENT,
 `question_content` VARCHAR(255) NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`question_id`)) ENGINE = InnoDB;
";

$sql10 = "
CREATE TABLE IF NOT EXISTS `website`.`return_item` (
 `return_id` VARCHAR(255) NOT NULL,
 `refund_id` VARCHAR(255) NOT NULL,
 `user_id` INT(255) NOT NULL,
 `order_item_id` INT(255) NOT NULL,
 `status` ENUM('pending', 'delivering', 'arrived', 'reject', 'missing', 'broken') NULL DEFAULT 'pending',
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 `update_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (`return_id`)) ENGINE = InnoDB;
";

$sql11 = "
CREATE TABLE IF NOT EXISTS orders (
    order_id VARCHAR(255) NOT NULL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    delivery_id VARCHAR(255) NOT NULL,
    coupon_id VARCHAR(255) NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'paid', 'shipped', 'delivered', 'cancelled', 'requestingRefund', 'requestingReturn', 'refundApproved', 'refundRejected') DEFAULT 'pending',
    create_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    update_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
";
 
$sql12 = "
CREATE TABLE IF NOT EXISTS order_items (
    `order_item_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `order_id` VARCHAR(255) NOT NULL,
    `product_id` VARCHAR(255) NOT NULL,
    `price` DECIMAL(10,2) NOT NULL,
    `quantity` INT NOT NULL,
    `status` ENUM('pending', 'paid', 'shipped', 'delivered', 'cancelled', 'requestingRefund', 'requestingReturn', 'refundApproved', 'refundRejected') DEFAULT 'pending',
    `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    `update_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`order_id`) REFERENCES orders(`order_id`) ON DELETE CASCADE
) ENGINE=InnoDB;
";
 
$sql13 = "
CREATE TABLE IF NOT EXISTS `website`.`transactions` (
 `transaction_id` VARCHAR(255) NOT NULL,
 `order_id` VARCHAR(255) NOT NULL,
 `user_id` VARCHAR(255) NOT NULL,
 `amount` VARCHAR(255) NOT NULL,
 `status` VARCHAR(255) NOT NULL,
 `transaction_date` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 `update_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (`transaction_id`)) ENGINE = InnoDB;
";
 
$sql14 = "
CREATE TABLE IF NOT EXISTS `website`.`shopping_cart` (
 `cart_id` INT(255) NOT NULL AUTO_INCREMENT,
 `user_id` VARCHAR(255) NOT NULL,
 `cart_name` VARCHAR(255) NOT NULL,
 `cart_discription` VARCHAR(255) NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 `update_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (`cart_id`)) ENGINE = InnoDB;
";
 
$sql15 = "
CREATE TABLE IF NOT EXISTS `website`.`cart_item` (
 `cart_item_id` INT(255) NOT NULL AUTO_INCREMENT,
 `cart_id` INT(255) NOT NULL,
 `product_id` VARCHAR(255) NOT NULL,
 `quantity` INT(255) NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 `update_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (`cart_item_id`)) ENGINE = InnoDB;
";

$sql16 = "
CREATE TABLE IF NOT EXISTS `website`.`users_delivery` (
 `delivery_id` VARCHAR(255) NOT NULL,
 `user_id` VARCHAR(255) NOT NULL,
 `first_name` VARCHAR(255) NOT NULL,
 `last_name` VARCHAR(255) NOT NULL,
 `contact_phone` INT(255) NOT NULL,
 `contact_email` VARCHAR(255) NOT NULL,
 `address1` VARCHAR(255) NOT NULL,
 `address2` VARCHAR(255) NOT NULL,
 `region` VARCHAR(255) NOT NULL,
 `city_area` VARCHAR(255) NOT NULL,
 `city` VARCHAR(255) NOT NULL,
 `city_code` VARCHAR(255) NOT NULL,
 `is_primary` int(2) NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 `update_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (`delivery_id`)) ENGINE = InnoDB;
";

$sql17 = "
CREATE TABLE IF NOT EXISTS `website`.`web_status` (
 `status` VARCHAR(255) NOT NULL,
 `description` VARCHAR(255) NOT NULL,
 `is_opening` VARCHAR(255) NOT NULL,
 `update_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
";

$sql18 = "
CREATE TABLE IF NOT EXISTS `website`.`web_activity` (
 `activity_id` INT(255) NOT NULL AUTO_INCREMENT,
 `description` VARCHAR(255) NOT NULL,
 `action_admin_id` VARCHAR(255) NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`activity_id`)) ENGINE = InnoDB;
";

$sql19 = "
CREATE TABLE IF NOT EXISTS `website`.`coupon` (
 `coupon_id` VARCHAR(255) NOT NULL,
 `coupon_target` VARCHAR(255) NOT NULL,
 `coupon_name` VARCHAR(255) NOT NULL,
 `duration` VARCHAR(255) NOT NULL,
 `coupon_type` ENUM('persentage', 'amount') NOT NULL,
 `discount` VARCHAR(255) NOT NULL,
 `limit_use` int(255) NOT NULL,
 `description` VARCHAR(255) NOT NULL,
 `image_url` VARCHAR(255) NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`coupon_id`)) ENGINE = InnoDB;
";

$sql20 = "
CREATE TABLE IF NOT EXISTS `website`.`coupon_usage` (
 `coupon_usage_id` INT(255) NOT NULL AUTO_INCREMENT,
 `coupon_id` VARCHAR(255) NOT NULL,
 `user_id` VARCHAR(255) NOT NULL,
 `order_id` VARCHAR(255) NOT NULL,
 `used_date` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`coupon_usage_id`)) ENGINE = InnoDB;
";
 
$sql21 = "
CREATE TABLE IF NOT EXISTS `website`.`coupon_admin_management` (
 `manage_id` INT(255) NOT NULL AUTO_INCREMENT,
 `admin_id` VARCHAR(255) NOT NULL,
 `coupon_id` VARCHAR(255) NOT NULL,
 `action` ENUM('create', 'delete') NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`manage_id`)) ENGINE = InnoDB;
";
 
$sql22 = "
CREATE TABLE IF NOT EXISTS `website`.`product_admin_management` (
 `manage_id` INT(255) NOT NULL AUTO_INCREMENT,
 `admin_id` VARCHAR(255) NOT NULL,
 `product_id` VARCHAR(255) NOT NULL,
 `action` ENUM('create', 'update', 'delete') NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`manage_id`)) ENGINE = InnoDB;
"; 
 
$sql23 = "
CREATE TABLE IF NOT EXISTS `website`.`user_admin_management` (
 `manage_id` INT(255) NOT NULL AUTO_INCREMENT,
 `admin_id` VARCHAR(255) NOT NULL,
 `user_id` VARCHAR(255) NOT NULL,
 `action` ENUM('create', 'update', 'delete') NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`manage_id`)) ENGINE = InnoDB;
"; 
 
$sql24 = "
CREATE TABLE IF NOT EXISTS product_icon (
    `product_icon_id` VARCHAR(255) NOT NULL PRIMARY KEY,
    `product_id` VARCHAR(255) NOT NULL,
    `url` VARCHAR(255) NOT NULL,
    `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    `update_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`product_id`) REFERENCES product(`product_id`) ON DELETE CASCADE
) ENGINE=InnoDB;
";
 
$sql25 = "
CREATE TABLE IF NOT EXISTS product_detail_image(
    `product_detail_image_id` VARCHAR(255) NOT NULL PRIMARY KEY,
    `product_id` VARCHAR(255) NOT NULL,
    `url` VARCHAR(255) NOT NULL,
    `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    `update_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`product_id`) REFERENCES product(`product_id`) ON DELETE CASCADE
) ENGINE=InnoDB;
";
 
$sql26 = "
CREATE TABLE IF NOT EXISTS refund(
    `refund_id` VARCHAR(255) NOT NULL PRIMARY KEY,
    `order_item_id` int(255) NOT NULL,
    `user_id` VARCHAR(255) NOT NULL,
    `amount` DECIMAL(10,2) NOT NULL,
    `status` ENUM('pending', 'approve', 'reject') NOT NULL,
    `reason` VARCHAR(255) NOT NULL,
    `return_id` VARCHAR(255) NULL,
    `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    `update_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`order_item_id`) REFERENCES order_items(`order_item_id`) ON DELETE CASCADE
) ENGINE=InnoDB;
";

$sql27 = "
CREATE TABLE IF NOT EXISTS `website`.`refund_admin_management` (
 `manage_id` INT(255) NOT NULL AUTO_INCREMENT,
 `admin_id` VARCHAR(255) NOT NULL,
 `refund_id` VARCHAR(255) NOT NULL,
 `action` ENUM('create', 'update', 'delete') NOT NULL,
 `updated_status` ENUM('pending', 'approve', 'reject') NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`manage_id`)) ENGINE = InnoDB;
"; 

$sql28 = "
CREATE TABLE IF NOT EXISTS `website`.`return_admin_management` (
 `manage_id` INT(255) NOT NULL AUTO_INCREMENT,
 `admin_id` VARCHAR(255) NOT NULL,
 `return_id` VARCHAR(255) NOT NULL,
 `action` ENUM('create', 'update', 'delete') NOT NULL,
 `updated_status` ENUM('pending', 'delivering', 'arrived', 'reject', 'missing', 'broken') NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`manage_id`)) ENGINE = InnoDB;
"; 

$sql29 = "
CREATE TABLE IF NOT EXISTS `website`.`review_admin_management` (
 `manage_id` INT(255) NOT NULL AUTO_INCREMENT,
 `admin_id` VARCHAR(255) NOT NULL,
 `review_id` VARCHAR(255) NOT NULL,
 `user_id` VARCHAR(255) NOT NULL,
 `action` ENUM('create', 'update', 'delete') NOT NULL,
 `modified_review_content` VARCHAR(255) NULL,
 `old_review_content` VARCHAR(255) NOT NULL,
 `review_content` VARCHAR(255) NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`manage_id`)) ENGINE = InnoDB;
"; 

$sql30 = "
CREATE TABLE IF NOT EXISTS `website`.`admin_admin_management` (
 `manage_id` INT(255) NOT NULL AUTO_INCREMENT,
 `admin_id` VARCHAR(255) NOT NULL,
 `affected_admin_id` VARCHAR(255) NOT NULL,
 `action` ENUM('create', 'update', 'delete') NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`manage_id`)) ENGINE = InnoDB;
"; 

$sql31 = "
CREATE TABLE IF NOT EXISTS `website`.`categories_admin_management` (
 `manage_id` INT(255) NOT NULL AUTO_INCREMENT,
 `admin_id` VARCHAR(255) NOT NULL,
 `categories_id` VARCHAR(255) NOT NULL,
 `action` ENUM('create', 'update', 'delete') NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`manage_id`)) ENGINE = InnoDB;
"; 

$sql32 = "
CREATE TABLE IF NOT EXISTS `website`.`home_page_layout_images` (
 `image_id` INT(255) NOT NULL AUTO_INCREMENT,
 `image_path` VARCHAR(255) NOT NULL,
 `image_title` VARCHAR(255) NOT NULL,
 `image_content` VARCHAR(255) NOT NULL,
 `image_button_name` VARCHAR(255) NOT NULL,
 `create_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`image_id`)) ENGINE = InnoDB;
"; 

$sql35 = "
CREATE TABLE IF NOT EXISTS `website`.`page_views` (
`page_views_id` INT AUTO_INCREMENT,
`page_url` VARCHAR(255) NOT NULL,
`user_id` VARCHAR(255) NULL,
`ip_address` VARCHAR(45) DEFAULT 0,
`view_date` DATE NOT NULL,
 PRIMARY KEY (`page_views_id`)) ENGINE = InnoDB;
"; 

$sql33 = "INSERT INTO `admin_role`(`role_name`, `description`) VALUES ('Creator','The top level of the admin')"; 
$sql34 = "INSERT INTO `admin`(admin_id, `role_id`, `user_name`, `email`, `password`, `status`) VALUES ('qwjlibghciuwyeoebfiwquldhoui', 1,'admin','admin@toolshop.sadnovice.com','forawswebsite2025','true')"; 
 
$sqlAry = array($sql, $sql2, $sql3, $sql4, $sql5, $sql6, $sql7, $sql8, $sql9, $sql10, $sql11, $sql12, $sql13, $sql14, $sql15, $sql16, $sql17, $sql18, $sql19, $sql20, $sql21, $sql22, $sql23, $sql24, $sql25, $sql26, $sql27, $sql28, $sql29, $sql30, $sql31, $sql32, $sql33, $sql34, $sql35);
 
for ($i = 0; $i < count($sqlAry); $i++) {
	if ($conn->query($sqlAry[$i]) === TRUE) {
		echo "Table ${i} created successfully";
		echo "<br>";
	} else {
		echo "Error creating table: " . $conn->error;
		echo "<br>";
	}
}

$conn->close();
?>