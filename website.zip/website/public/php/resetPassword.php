<?php
include 'credentials.php';

$data = json_decode(file_get_contents("php://input"), true);

$servername = $credentials['host'];
$username = $credentials['username'];
$password = $credentials['password'];
$dbname = $credentials['dbname'];

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Input from the user (use actual form inputs)
$resetEmail = $_POST['resetEmail'];
$resetPassword = $_POST['resetPassword'];
$securityQuestion = $_POST['securityQuestion'];
$securityQuestionAnswer = $_POST['securityQuestionAnswer'];

if (!empty($resetEmail) && !empty($securityQuestion) && !empty($securityQuestionAnswer)) {
    // Prepare the SQL query securely
    $stmt = $conn->prepare("SELECT secuity_question_id, secuity_question_answer FROM user WHERE email = ?");
    $stmt->bind_param("s", $resetEmail); // 's' specifies the type: string
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
		$row = $result->fetch_assoc();
		$secuity_question_id = $row['secuity_question_id'];
        $secuity_question_answer = $row['secuity_question_answer'];
		
		if ($securityQuestion == $secuity_question_id && $securityQuestionAnswer == $secuity_question_answer) {
			$stmt = $conn->prepare("update user set password = ? where email = ?");
			$stmt->bind_param("ss", $resetPassword, $resetEmail); // 's' specifies the type: string

			if ($stmt->execute()) {
				echo "Password reset successfully.";
			}
			else {
				echo "Password reset failure.";
			}
		}
		else {
			echo "Wrong security question or answer.";
		}
    } else {
		echo "Account doesn't existed.";
    }
    $stmt->close();
} else {
    echo "Both username and password are required.";
}

$conn->close();
?>
