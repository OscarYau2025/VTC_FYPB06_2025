<?php
include 'credentials.php';
	session_start();
	if (!isset($_SESSION['loggedIn']))
		$_SESSION['loggedIn'] = false;
	if (!isset($_SESSION['email']))
		$_SESSION['email'] = null;
	if (!isset($_SESSION['userId']))
		$_SESSION['userId'] = null;
	
	if ($_POST['loggedIn'] == "" && $_POST['email'] == "" && $_POST['userId']) {
		echo "fail";
		die;
	}
	
	$_SESSION['loggedIn'] = $_POST['loggedIn'];
	$_SESSION['email'] = $_POST['email'];
	$_SESSION['userId'] = $_POST['userId'];
	
	if ($_SESSION['loggedIn'] == true && isset($_SESSION['email']) && isset($_SESSION['userId'])) {
		$data = $_SESSION['loggedIn'] . ":" . $_SESSION['email'] . ":" . $_SESSION['userId'];
		echo $data;
	}
	else {
		echo "fail";
	}
?>