<?php
include 'credentials.php';

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

	$data = json_decode(file_get_contents("php://input"), true);

	$servername = $credentials['host'];
	$username = $credentials['username'];
	$password = $credentials['password'];
	$dbname = $credentials['dbname'];

	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

	// Input from the user (use actual form inputs)
	$inputEmail = $_POST['email'];
	$inputPassword = $_POST['password'];

	if (!empty($inputEmail) && !empty($inputPassword)) {
		// Prepare the SQL query securely
		$stmt = $conn->prepare("SELECT password FROM user WHERE email = ?");
		$stmt->bind_param("s", $inputEmail); // 's' specifies the type: string
		$stmt->execute();
		$result = $stmt->get_result();

		if ($result->num_rows > 0) {
			$user = $result->fetch_assoc();

			// Verify the password securely (if stored as a hashed password)
			if ($inputPassword == $user['password']) {
				echo "case1";
				$_SESSION['loggedIn'] = true;
				$_SESSION['email'] = $inputEmail;
				
				$stmt = $conn->prepare("SELECT user_id FROM user WHERE email = ?"); // Select the user ID
				$stmt->bind_param("s", $inputEmail); // Bind the email parameter
				$stmt->execute();
				$result = $stmt->get_result();

				if ($row = $result->fetch_assoc()) {
					$userId = $row['user_id']; // Fetch the user ID
					echo "User ID:" . $userId;
				} else {
					echo "No user found with that email.";
				}
			} else {
				echo "case2";
			}
		} else {
			echo "case3";
		}

		$stmt->close();
	} else {
		echo "Both username and password are required.";
	}
}

$conn->close();
?>
