<?php
	session_start();
	if (isset($_SESSION['loggedIn']) && isset($_SESSION['email']) && isset($_SESSION['userId'])) {
		if ($_SESSION['loggedIn'] == true) {
			$data = $_SESSION['loggedIn'] . ":" . $_SESSION['email'] . ":" . $_SESSION['userId'];
			echo $data;
		}
		else {
			echo "fail";
		}
	}
	else {
		echo "fail";
	}
?>