<?php
$credentials = [
    'host' => 'localhost',
    'dbname' => 'website',
    'username' => 'root',
    'password' => ''
];
/*
$credentials = [
    'host' => 'database-1.c4reaoueqsph.us-east-1.rds.amazonaws.com',
    'dbname' => 'website',
    'username' => 'admin',
    'password' => 'Forawswebsite2025!'
];*/
?>
