<?php
include 'credentials.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$servername = $credentials['host'];
$username = $credentials['username'];
$password = $credentials['password'];
$dbname = $credentials['dbname'];

$data = json_decode(file_get_contents("php://input"), true);


$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Input from the user (use actual form inputs)
$inputEmail = $_POST['email'];
$inputPassword = $_POST['password'];
$secuity_id = $_POST['secuity_id'];
$secuity_answer = $_POST['secuity_answer'];

if (!empty($inputEmail) && !empty($inputPassword)) {
    // Prepare the SQL query securely
    $stmt = $conn->prepare("SELECT email FROM user WHERE email = ?");
    $stmt->bind_param("s", $inputEmail); // 's' specifies the type: string
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "Account existed";
    } else {
		$userId = generateRandomString(50);
        $stmt = $conn->prepare("INSERT into user (user_id, email, password, secuity_question_id, secuity_question_answer) values (?, ?, ?, ?, ?)");
		$stmt->bind_param("sssis", $userId, $inputEmail, $inputPassword, $secuity_id, $secuity_answer); // 's' specifies the type: string

		if ($stmt->execute()) {
			
			$stmt2 = $conn->prepare("INSERT into shopping_cart (user_id, cart_name, cart_discription) values (?, ?, 'null')");
			$stmt2->bind_param("ss", $userId, $userId); // 's' specifies the type: string
			if ($stmt2->execute()) {
				echo "Account create successfully.";
			}
			else {
				echo "Account create failure.";
			}
		}
		else {
			echo "Account create failure.";
		}
    }
    $stmt->close();
} else {
    echo "Both username and password are required.";
}

$conn->close();

function generateRandomString($length) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

?>
