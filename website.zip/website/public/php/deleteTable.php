<?php
include 'credentials.php';
$servername = $credentials['host'];
$username = $credentials['username'];
$password = $credentials['password'];
$dbname = $credentials['dbname'];

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// List of table names to drop
$tables = [
    "admin", "admin_admin_management", "admin_role", "cart_item", "categories",
    "categories_admin_management", "coupon", "coupon_admin_management", "coupon_usage",
    "discount", "home_page_layout_images", "order_admin_management", "order_items", "orders",
    "product", "product_admin_management", "product_detail_image", "product_icon", "refund",
    "refund_admin_management", "return_admin_management", "return_item", "review",
    "review_admin_management", "security_questions", "shopping_cart", "transactions", "user",
    "user_admin_management", "users_delivery", "web_activity", "web_status", "page_views"
];

// Disable foreign key checks
$conn->query("SET FOREIGN_KEY_CHECKS = 0;");

// Loop through and drop each table
foreach ($tables as $table) {
    $sql = "DROP TABLE IF EXISTS `$table`";
    if ($conn->query($sql) === TRUE) {
        echo "Table $table deleted successfully.<br>";
    } else {
        echo "Error deleting table $table: " . $conn->error . "<br>";
    }
}

// Enable foreign key checks
$conn->query("SET FOREIGN_KEY_CHECKS = 1;");

// Close the connection
$conn->close();
?>