let reviewSuccess = false;

const filterContent = `<div class="col-12 pb-1">
					<div class="d-flex align-items-center justify-content-between mb-4">
						<div class="input-group">
							<input type="text" class="form-control" id="searchByName" placeholder="Search by name">
							<div class="input-group-append">
								<span class="input-group-text bg-transparent text-primary">
									<i class="fa fa-search"></i>
								</span>
							</div>
						</div>
						<div class="dropdown ml-4">
							<button class="btn border dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true"
									aria-expanded="false">
										Sort by
									</button>
							<div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
								<a class="dropdown-item" href="#">Latest</a>
								<a class="dropdown-item" href="#">Popularity</a>
								<a class="dropdown-item" href="#">Best Rating</a>
							</div>
						</div>
					</div>
				</div>`;
				
const productContent = document.getElementById("productView");

const params = new URLSearchParams(new URL(window.location.href).search);
const page = params.get('page');
const category = params.get('category');
const keywords = params.get('keywords');

getProduct();

function paging(movingPage) {
	const currentUrlWithoutParams = window.location.origin + window.location.pathname;
	window.location.href = currentUrlWithoutParams + "?page=" + movingPage;
}

function getProduct() {
	const url = address + 'getProductContent';
	let pageNum = parseInt(page);
	
	if (isNaN(pageNum) || !page) {
		pageNum = 1;
	}
	
	let formData = new FormData();
	formData.append("page", pageNum);
	formData.append("productCategory", category);
	formData.append("keywords", keywords);
	
	// Send the POST request
	fetch(url, {
	  method: 'POST',
	  body: formData, // No need for JSON.stringify when using FormData
	})
	  .then(response => {
		if (response.status == 200){
			reviewSuccess = true;
		}
		return response.text();
	  })
	  .then(result => {
		if (reviewSuccess) {
			//productContent.innerHTML = filterContent + result;
			productContent.innerHTML = result;
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
  });
}

async function addToCart(shopProductId) {
	try {
		const url = `${address}add_cartItem`;
		const formData = new FormData();
		formData.append("productId", shopProductId);
		formData.append("userId", userId);
		formData.append("quantity", 1);

		const response = await fetch(url, {
			method: "POST",
			body: formData,
			credentials: 'include',
		});

		const result = await response.text();
		if (result.includes("successfully")) {
			alert(result);
		} 
		else {
			alert("Add to cart failed, please try again later, or relogin.");
			openLoginPanel(true);
		}
	}
	catch (err) {
		console.error("Error in addToCart:", err);
		openLoginPanel(true);
	}
}