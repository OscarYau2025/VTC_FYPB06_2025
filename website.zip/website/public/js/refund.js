const urlParams = new URLSearchParams(window.location.search);

// Get specific parameters
const orderItemId = urlParams.get('orderItemId'); // Retrieves '123'

const productName = document.getElementById("productName");
const priceFormula = document.getElementById("priceFormula");
const totalAmount = document.getElementById("totalAmount");
const reason = document.getElementById("reason");
const isReturn = document.getElementById("isReturn");

function refund(order, isReturn) {
	const url = address + 'insertRefund';
	let formData = new FormData();
	
	formData.append("userId", userId);
	formData.append("orderItemId", document.getElementById("productName").dataset.order_item_id);
	formData.append("reason", document.getElementById("reason").value);
	formData.append("isReturn", document.getElementById("isReturn").checked);
	
	fetch(url, {
		method: 'POST',
		body: formData,
	})
	.then(response => response.text())
	.then(result => {
		if (result.includes("successfully")) {
			alert("Request refund successfully");
			window.location.href = "userCenter.html";
		}
	})
}

function getRefundProduct() {
	const url = address + 'get_refundProduct';
	
	let formData = new FormData();
				
	formData.append("orderItemId", orderItemId);
	formData.append("userId", userId);
	
		fetch(url, {
			method: 'POST',
			body: formData,
		})
		.then(response => response.text())
		.then(result => {
			document.getElementById("refundForm").innerHTML = result;
		})
	.catch(error => {
		console.error('Error:', error);
	});	
}

getRefundProduct();