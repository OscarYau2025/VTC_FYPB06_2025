const orderListContainer = document.getElementById("orderList_container");

async function getOrderDetailList() {
	try {
		const url = address + 'get_order';
		let formData = new FormData();
		formData.append("userId", userId);
		fetch(url, {
		method: 'POST',
		body: formData,
		})
		.then(response => response.text())
		.then(result => {
			orderListContainer.innerHTML = result;
		})
		.catch(error => {
			alert("There's something wrong, please refresh page and try again later");
		});
	} catch (err) {
		openLoginPanel(true);
	}
}

async function removeItem(item) {
	try {
		const url = address + 'remove_item';
		let formData = new FormData();
		formData.append("item", item);
		formData.append("userId", userId);
		fetch(url, {
			method: 'POST',
			body: formData,
		})
		.then(response => response.text())
		.then(result => {
			if (result == "successfully") {
				alert("Remove order successfully");
				window.location.reload();
			}
		})
		.catch(error => {
			alert("There's something wrong, please refresh page and try again later");
		});	
	} catch (err) {
		openLoginPanel(true);
	}
}


async function pay(order) {
	try {
		const isAuthorized = await accessProtectedRoute();
		if (isAuthorized) {
			const url = address + 'pay_order';
			let formData = new FormData();
			formData.append("userId", userId);
			formData.append("order", order);
			fetch(url, {
				method: 'POST',
				body: formData,
			})
			.then(response => response.text())
			.then(result => {
				window.location.href = result;
		})
		.catch(error => {
				alert("There's something wrong, please refresh page and try again later");
			});					
		}
		else {
			openLoginPanel(true);
		}
	} catch (err) {
		openLoginPanel(true);
	}
}

function checkOrder(order) {
	
	window.location.href = "orderSuccess.html?order=" + order;
}

getOrderDetailList();