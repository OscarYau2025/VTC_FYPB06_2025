function getHomeCarouselImage() {
	const url = address + 'get_home_carouselImage';

	// Send the POST request
	fetch(url, {
	  method: 'POST',
	})
	  .then(response => {
		if (response.status == 200){
			reviewSuccess = true;
		}
		return response.text();
	  })
	  .then(result => {
		if (reviewSuccess) {
			document.getElementById("homeCarousel").innerHTML = result;
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
  });
}
getHomeCarouselImage();