let couponGot = false;
let itemGot = false;
let originSubTotal = 0;
let shippingFee = 30;

function getCartItem() {
	const url = address + 'get_cartItem';
	let formData = new FormData();
	formData.append("userId", userId);
	formData.append("isOrder", false);
	fetch(url, {
		method: 'POST',
		body: formData,
	})
	.then(response => response.text())
	.then(result => {
		if (result != "null") {
				document.getElementById("cartItemTable").innerHTML = result;
				let elements = document.getElementsByName('productTotalPrice'); 
				let subTotal = 0;

				elements.forEach(element => {
					subTotal += parseFloat(element.innerHTML.replace("$", "")); // Correctly add the parsed numeric value
				})
				document.getElementById("subtotalAmong").innerHTML = "$" + subTotal;
				document.getElementById("totalAmong").innerHTML = "$" + (subTotal + parseFloat(document.getElementById("shippingAmong").innerHTML.replace("$", "")));

				originSubTotal = parseFloat(subTotal);

				itemGot = true;

				if (couponGot && itemGot)
					recalCouponDiscount();
			}
		else {
			document.getElementById("cartContainer").innerHTML = `<h4 class="font-weight-semi-bold mb-4">Not item in cart? Click <label style='color:red' onclick='openurl("shop.html")'>me</label> to shop</h4>`;
		}
	});
}
getCartItem();

function changeItemStatus(num, productGridId, isReplace) {

	const url = address + 'modify_cartItem';
	let formData = new FormData();
	formData.append("productGridId", productGridId);
	if (!isReplace)
		formData.append("quantity", parseInt(document.getElementById('quantity' + productGridId).value) + num);
	else 
		formData.append("quantity", parseInt(num));
	
	fetch(url, {
		method: 'POST',
		body: formData,
	})
	.then(response => response.text())
	.then(result => {
		if (result.includes("successfully")) {
			getCartItem();
		}
	});
}

function getCoupon() {
	const url = address + 'userGetCoupon';
	let formData = new FormData();
	formData.append("userId", userId);
	fetch(url, {
		method: 'POST',
		body: formData,
	})
	.then(response => {
		return response.text();
	})
	.then(result => {		
		document.getElementById("couponSelection").innerHTML = `<option value="">Without Coupon</option>` + result;
		couponGot = true;
		if (couponGot && itemGot)
			recalCouponDiscount();
	})
	.catch(error => {
		//alert(error);
	});
}
getCoupon();

function checkOut() {
	window.location.href = 'order.html?coupon=' + document.getElementById("couponSelection").value;

}

function recalCouponDiscount() {
	couponSelection = document.getElementById("couponSelection");

	couponGot = false;
	itemGot = false;

	if (!couponSelection[couponSelection.selectedIndex].dataset.coupon_type) {
		document.getElementById("subtotalAmong").innerHTML = "$" + originSubTotal
		document.getElementById("totalAmong").innerHTML = "$" + (originSubTotal + shippingFee);
	}
	else {
		if (couponSelection[couponSelection.selectedIndex].dataset.coupon_type == "persentage") {
			document.getElementById("subtotalAmong").innerHTML = "$" + (originSubTotal * parseFloat(couponSelection[couponSelection.selectedIndex].dataset.discount) / 100);
			document.getElementById("totalAmong").innerHTML = "$" + (originSubTotal * parseFloat(couponSelection[couponSelection.selectedIndex].dataset.discount) / 100 + shippingFee);
		}
		else if (couponSelection[couponSelection.selectedIndex].dataset.coupon_type == "amount") {
			document.getElementById("subtotalAmong").innerHTML = "$" + (originSubTotal - parseFloat(couponSelection[couponSelection.selectedIndex].dataset.discount));
		}
	}
}