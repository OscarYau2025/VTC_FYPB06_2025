//const address = 'http://localhost:8080/';
//const siteLink = 'http://localhost/website/public/';
const address = 'https://toolshop.sadnovice.com:8080/';
const siteLink = 'https://toolshop.sadnovice.com/';

const pageTitle = "EShopper-Tool Shop ";
const userId = localStorage.getItem('userId');;

let componentAry = ["header", "footer", "navContainer"];
Promise.all(
  componentAry.map(async (component) => {
    const element = document.getElementById(component);
    if (element) {
      try {
        const response = await fetch(siteLink + "component/" + component + ".html");
        if (!response.ok) throw new Error("Failed to load " + component);
        const data = await response.text();
        element.innerHTML = data;
      } catch (error) {
        console.error(error);
      }
    }
  })
).then(() => {
    accessProtectedRoute(); // Run after all components are loaded
});

if (window.location.href.includes(siteLink + "index.php") || window.location.href.split('?')[0] == (siteLink))
	document.title = pageTitle + "Home";
else if (window.location.href.includes(siteLink + "cart.html"))
	document.title = pageTitle + "Cart";
else if (window.location.href.includes(siteLink + "userCenter.html"))
	document.title = pageTitle + "User Center";
else if (window.location.href.includes(siteLink + "shop.html"))
	document.title = pageTitle + "Shop";
else if (window.location.href.includes(siteLink + "contact.html"))
	document.title = pageTitle + "Contact";
else if (window.location.href.includes(siteLink + "products/"))
	document.title = pageTitle + "Product";
else if (window.location.href.includes(siteLink + "order.html"))
	document.title = pageTitle + "Order";
else if (window.location.href.includes(siteLink + "orderCancel.html"))
	document.title = pageTitle + "Cancel";
else if (window.location.href.includes(siteLink + "orderList.html"))
	document.title = pageTitle + "Order List";
else if (window.location.href.includes(siteLink + "orderSuccess.html"))
	document.title = pageTitle + "Order Success";
else if (window.location.href.includes(siteLink + "refund.html"))
	document.title = pageTitle + "Refund";
else if (window.location.href.includes(siteLink + "register.html"))
	document.title = pageTitle + "Register";
else if (window.location.href.includes(siteLink + "qualityProduct.html"))
	document.title = pageTitle + "Quality Product";
else if (window.location.href.includes(siteLink + "reasonableReturn.html"))
	document.title = pageTitle + "Reasonable Return Product";
else if (window.location.href.includes(siteLink + "shipping.html"))
	document.title = pageTitle + "Shipping";

const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;


function openLoginPanel(isOpen) {
	if (isOpen) {
		document.getElementById("login-panel").style.display = "block";
		document.getElementById("login-panel").style.opacity = 0;
	}
	else {
		document.getElementById("login-panel").style.display = "none";
	}
}

function openResetPasswordPage(isOpen) {
	if (isOpen) {
		getSecurityQuestion();
		document.getElementById("resetPasswordPanel").style.display = "block";
		document.getElementById("resetPasswordPanel").style.opacity = 0;
		document.getElementById("login-panel").style.display = "none";
	}
	else if (isOpen == false) {
		document.getElementById("resetPasswordPanel").style.display = "none";
	}
	else {
		document.getElementById("resetPasswordPanel").style.display = "none";
		document.getElementById("login-panel").style.display = "block";
		document.getElementById("login-panel").style.opacity = 0;
	}
}

function getSecurityQuestion() {
	fetch(address + "getSecureityQuestion", {
	  method: 'POST',
	  headers: {
		'Content-Type': 'application/json'
	  },
	})

	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		document.getElementById("securityQuestion").innerHTML = result;
		document.getElementById("securityQuestion2").innerHTML = result;
	  })
	  .catch(error => {
		console.error('Error:', error);
	  });
}

function resetPassword() {
	
	if (document.getElementById("resetPassword").value.trim() == "" || document.getElementById("resetEmail").value.trim() == "") {
		alert("Please fill in all the input fields");
		return;
	}
	else if (document.getElementById("resetPassword").value != document.getElementById("resetConfirmPassword").value) {
		alert("Passwords doesn't match");
		return;
	}
	
	const formData = new FormData();
	formData.append("resetEmail", document.getElementById("resetEmail").value);
	formData.append("securityQuestion", document.getElementById("securityQuestion2")[document.getElementById("securityQuestion2").selectedIndex].id);
	formData.append("resetPassword", document.getElementById("resetPassword").value);
	formData.append("securityQuestionAnswer", document.getElementById("securityQuestionAnswer").value);

	fetch(siteLink + "php/resetPassword.php", {
		method: "POST",
		body: formData
	})
	.then(response => response.text()) // Read response as text
	.then(data => {
		alert(data);
		if (data.includes("successfully")) {
			window.location.reload();
		}
	})
	.catch(error => {
		alert("Account create failure, please retry it later.");
	});
}

function udpatePageView() {
	const formData = new FormData();
	formData.append("userId", userId);
	formData.append("page", document.title);
	
  fetch(address + 'udpate_page_view', {
		method: "POST",
		body: formData
	})
	.then(response => response.text()) // Read response as text
	.then(data => {
	});
}

udpatePageView();

function getHomeCategories() {
  fetch(address + 'get_categorie_homePage', {
		method: "POST",
	})
	.then(response => response.text()) // Read response as text
		.then(data => {
			document.getElementById("navbar-vertical").innerHTML = data;
	});
}

function search(byName) {
	let shopURL = 'shop.html';
	
	if (window.location.href.includes("products/"))
		shopURL = window.location.href.split("products/")[0] + shopURL;
	
	if (!byName)
		window.location.href = shopURL + "?keywords=" + document.getElementById("searchInput").value;
	else {		
		const params = new URLSearchParams(new URL(window.location.href).search);
		const category = params.get('category');
		if (category) {
			window.location.href = shopURL + "?category=" + category + "keywords=" + document.getElementById("searchInput").value;
		}
		else {
			window.location.href = shopURL + "?keywords=" + document.getElementById("searchInput").value;
		}
	}
}

function searchCategory(id) {
	if (window.location.href.includes('products/'))
		window.location.href = window.location.href.split("products/")[0] + "shop.html?category=" + id;
	else 
		window.location.href = `shop.html?category=${id}`;
}

document.addEventListener("keydown", function(event) {
    let inputField = document.getElementById("myTextInput");

    // Check if Enter key (key code 13) was pressed and input field is focused
    if (event.key === "Enter") {
		event.preventDefault();

		if (window.location.href.includes(siteLink + "shop.html")) {
			if (document.activeElement === document.getElementById("searchInput"))
				window.location.href = "shop.html?keywords=" + document.getElementById("searchInput").value;
			else if (document.activeElement === document.getElementById("searchByName")) {
				window.location.href = "shop.html?category=" + category + "&keywords=" + document.getElementById("searchByName").value;
			}
		}
		else if (document.activeElement === document.getElementById("loginEmail") || document.activeElement === document.getElementById("loginPassword")) {
			login();
		}
    }
	return;
});

function openurl(url) {
	window.location.href = siteLink + url;
}

async function login(username, password) {
	const loginEmail = document.getElementById("loginEmail").value;
	const loginPassword = document.getElementById("loginPassword").value;

	try {
		const response = await fetch(`${address}login`, {
			method: 'POST',
			credentials: 'include', // Ensures cookies are included in requests
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ userEmail: loginEmail, password: loginPassword })
		});

		if (response.status === 200) {
			const result = await response.json();
			localStorage.setItem("userId", result);
			// No need to manually store tokens, cookies will handle them
			if (window.location.href === siteLink + "register.html") {
				window.location.href = siteLink + "index.php";
			} else {
				window.location.reload();
			}
		} else {
			document.getElementById("loginErrorMessage").innerHTML = "Invalid email or password";
		}
	} catch (err) {
		console.error('Error:', err);
	}

}

async function accessProtectedRoute() {
  try {
    const response = await fetch(`${address}protected`, {
      method: 'GET',			
	  credentials: 'include', // Ensures cookies are included in requests
    });
	
    if (response.ok) {
      const data = await response.json();
	  document.getElementById("userActionArea").innerHTML = `<button onclick="logout()" id="logoutBtn" class="nav-item nav-link">Logout</button>`;
	  return true;
    } else {
      // Handle unauthorized or failed access
      if (response.status === 401) {
        console.error('Access denied: Token expired or invalid.');
      } else {
        console.error(`Access denied: ${response.statusText}`);
      }
	  document.getElementById("userActionArea").innerHTML = `<button onclick="openLoginPanel(true)" id="loginBtn" class="nav-item nav-link">Login</button>
		<button onclick="openurl('register.html')" class="nav-item nav-link">Register</button>`;
		return false;
    }
  } catch (err) {
    console.error('Error occurred while accessing protected route:', err.message || err);
	return false;
  }
}

async function logout() {
	try {
		const response = await fetch(`${address}logout`, {
		  method: 'post',			
		  credentials: 'include', // Ensures cookies are included in requests
		});

		if (response.ok) {
		    window.location.reload();
			return;
		} else {
		  if (response.status === 401) {
			console.error('Access denied: Token expired or invalid.');
		  } else {
			console.error(`Access denied: ${response.statusText}`);
		  }
		  alert("Server no response, please try again later");
		}
	} catch (err) {
		console.error('Error occurred while accessing protected route:', err.message || err);
		return false;
	}
}
getHomeCategories();
/*
accessProtectedRoute()
  .then(isAuthorized => {
    console.log('Access granted:', isAuthorized); // Logs true or false
  })
  .catch(err => {
    console.error('Error occurred while accessing protected route:', err);
  });
  */
