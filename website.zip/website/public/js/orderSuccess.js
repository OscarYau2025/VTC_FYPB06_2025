const orderContainer = document.getElementById("order_container");

const params = new URLSearchParams(new URL(window.location.href).search);
const order = params.get('order');

//window.history.pushState(null, null, window.location.origin + window.location.pathname);

function orderStatus() {
	
	const url = address + 'orderStatus';
	let formData = new FormData();
	formData.append("order", order);
	fetch(url, {
	method: 'POST',
	body: formData,
	})
	.then(response => response.text())
	.then(result => {
		if (result.includes("Please")) {
			orderContainer.innerHTML = `<h2><center>Ordered already? Go <label onclick="window.location.href = 'orderList.html'" style="color:red">track</label> you order status</center></h2>`;
		}
		else 
			orderContainer.innerHTML = result;
		console.log(result);
	})
	.catch(error => {
		console.error('Error:', error);
	});	
}

function updateOrder() {
	const url = address + 'updateOrderStatusWhenSuccess';
	let formData = new FormData();
	formData.append("order", order);
	formData.append("action", "pay");
	formData.append("userId", userId);
	fetch(url, {
		method: 'POST',
		body: formData,
	})
	.then(response => response.text())
	.then(result => {
		console.log(result);
		orderStatus();
	})
}

if (order != null) {
	if (order.trim() != "") {
			updateOrder();
		}
	else {
		orderContainer.innerHTML = `<h2><center>Ordered already? Go <label onclick="window.location.href = 'orderList.html'" style="color:red">track</label> you order status</center></h2>`;
	}

}
else {
	orderContainer.innerHTML = `<h2><center>Ordered already? Go <label onclick="window.location.href = 'orderList.html'" style="color:red">track</label> you order status</center></h2>`;
}

async function printOrder() {
	const element = document.getElementById('orderListTable');
	const canvas = await html2canvas(element, {scale: 3 });
	
	var imgData = canvas.toDataURL("image/jpeg", 1);
	var pdf = window.jspdf.jsPDF();

	// Get the canvas dimensions
	var canvasWidth = canvas.width;
	var canvasHeight = canvas.height;
	
	var marginLeft = 10; // Left margin in mm
	var marginTop = 10;  
	
	// Define the PDF dimensions
	var pdfWidth = pdf.internal.pageSize.getWidth()- marginLeft * 2;
	var pdfHeight = pdf.internal.pageSize.getHeight()- marginTop * 2;

	// Calculate the scale factor to fit the canvas within the PDF dimensions
	var scaleFactor = Math.min(pdfWidth / canvasWidth, pdfHeight / canvasHeight);

	// Draw the scaled canvas onto the PDF
	pdf.addImage(imgData, 'JPEG', marginLeft, marginTop, canvasWidth * scaleFactor, canvasHeight * scaleFactor);
	pdf.save("order.pdf");
}