function getOrderListForReturn() {
	document.getElementById('returnContentContainer').style.display = "flex";

	const formData = new FormData();
	formData.append("userId", userId);

	fetch(address + "getOrderListForReturn", {
		method: "POST",
		body: formData
	})
	.then(response => response.json()) // Read response as text
	.then(data => {
		const result = data;
		let temp = "";
		let orderNum = 0;
		let orderid = 1;
		
		console.log(result);
		result.forEach((row) => {
			if (orderid != row.order_id) {
				orderNum++;
				orderid = row.order_id;
			}
			
			let priceAfterCal = parseFloat(row.product_price);
			
			if (row.coupon_id != null) {
				if (row.coupon_type == "persentage") {
					priceAfterCal = priceAfterCal * parseFloat(row.discount) / 100;
				}
			}
				
			temp += `<tr>
						<th>${orderNum}</th>
						<th><a href="${row.product_url}">${row.product_name}</a></th>
						<th>$${row.product_price}</th>
						<th>${row.quantity}</th>
						<th>$${parseInt(row.quantity) * priceAfterCal}</th>
						<th style="color:red">${row.status}</th>
						<th>
							${(row.status == "pending") ? `
							<label onclick="pay('${row.order_id}')" style="color: #d19c97">Pay</label><br>
							<label onclick="removeItem('${row.order_item_id}')" style="color: #d19c97">Remove</label><br>` :
							(row.status == "paid" || row.status == "shipped" || row.status == "delivered") ?
							`<a href="refund.html?orderItemId=${row.order_item_id}" style="color: #d19c97">Refund</a><br>` : ""}
							<a href="orderSuccess.html?order=${row.order_id}" target="_blank">Detail</a>
							</th>
					</tr>`;
		});
		
		if (temp != 0) {
			resultRow = `<table class="table table-bordered text-center mb-0">
					<thead class="bg-secondary text-dark">
						<tr>
							<th>Order No.</th>
							<th>Products</th>
							<th>Price</th>
							<th>Quantity</th>
							<th>Total</th>
							<th>Status</th>
							<th>Remove</th>
						</tr>
					</thead>
					<tbody class="align-middle" id="cartItemTable">` + temp + `</tbody>
				</table>`;
		}
		else {
			resultRow = `<h3><center>No order? <label onclick="window.location.href = 'shop.html'" style="color: red">Search</label> the things you need</center></h3>`;
		}
		document.getElementById('returnContent').innerHTML = `<h2 class="font-weight-semi-bold text-uppercase mb-3" style="padding:20px;">Refundable Products</h2>`;
		document.getElementById('returnContent').innerHTML += resultRow;
		document.getElementById('returnContent').innerHTML += `<br><button onclick='{document.getElementById("returnContentContainer").style.display = "none"}' class="btn btn-block btn-primary my-3 py-3">Close</button>`;
		
	})
	.catch(error => {
		console.error(error);
	});
}