const orderDetail = document.getElementById("orderDetail");

const params = new URLSearchParams(new URL(window.location.href).search);
const coupon = params.get('coupon');

function getOrderDetail() {
	const url = address + 'get_cartItem';
	let formData = new FormData();
	formData.append("userId", userId);
	formData.append("isOrder", true);
	fetch(url, {
	method: 'POST',
	body: formData,
	})
	.then(response => response.text())
	.then(result => {
		if (result != "null") {
			document.getElementById("orderDetail").innerHTML = result.split(":")[0];
			document.getElementById("totalAmong").innerHTML = "$" + result.split(":")[1];
		}
		else {
			document.getElementById("orderContainer").remove();
		}
	})
	.catch(error => {
		console.error('Error:', error);
	});	
}
function getOrderDelivery() {
	const url = address + 'get_OrderDelivery';
	let formData = new FormData();
	formData.append("userId", userId);
	formData.append("isOrder", true);
	fetch(url, {
		method: 'POST',
		body: formData,
	})
	.then(response => response.text())
	.then(result => {
		if (result == "") {
			document.getElementById("addressDIv").innerHTML = `
				<div style="display: flex; align-items: center;">
				<h4 class="font-weight-semi-bold mb-4">No address? Click <label style="color:red" onclick="window.location.href='userCenter.html'">me</label> to user center</h4>
				</div>`;
			document.getElementById("orderBtn").disabled = true;
		}
		else {
			document.getElementById("addressDIv").innerHTML = `
			<div style="display: flex; align-items: center;" onclick="window.location.href='userCenter.html'">
			<h4 class="font-weight-semi-bold mb-4">Delivery Address</h4>
		</div>`;
			document.getElementById("addressContent").innerHTML = result;
		}
	})
}

//productId, userId, orderStatus, product_name, product_url, price, quantity

function order() {
	const url = address + 'order';
	let formData = new FormData();
	formData.append("userId", userId);
	formData.append("deliveryId", document.getElementById("deliveryAddressDeliveryGroup").dataset.delivery_id);
	if (coupon)
		formData.append("coupon", coupon);

	fetch(url, {
		method: 'POST',
		body: formData,
	})
	.then(response => response.text())
	.then(result => {
		if (!result.includes("No"))
			window.location.href = result;
		else if ("invalid") {
			alert(result);
			window.location.reload();
		}
		else {
			alert("Cart item not found");
			window.location.reload();
		}
	})
}

getOrderDetail();
getOrderDelivery();