const productName = document.getElementById("productName");
const price = document.getElementById("price");
const stockLevel = document.getElementById("stockLevel");
const description = document.getElementById("productDescription");
const title = document.getElementById("title");

const url = address + 'productPage_getProduct';
let formData = new FormData();
formData.append("productId", productId);

fetch(url, {
	method: 'POST',
	body: formData,
})
.then(response => response.json())
.then(result => {
	productName.innerHTML = result.productName;
	title.innerHTML = result.productName;
	price.innerHTML = "$" + result.price;
	stockLevel.innerHTML = "In Stock " + result.stockLevel;
	description.innerHTML = result.description;
});