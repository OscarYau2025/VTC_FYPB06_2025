const firstName = document.getElementById("firstName");
const lastName = document.getElementById("lastName");
const contactPhone = document.getElementById("contactPhone");
const contactEmail = document.getElementById("contactEmail");
const address1 = document.getElementById("address1");
const address2 = document.getElementById("address2");
const cityArea = document.getElementById("cityArea");
const region = document.getElementById("region");
const city = document.getElementById("city");
const cityCode = document.getElementById("cityCode");
const isPrimary = document.getElementById("isPrimary");

const deliveryAddress = document.getElementById("deliveryAddress");

function setDeliveryDetail() {
	const url = address + 'create_delivery';
	const formData = new FormData();
	formData.append("userId", userId);
	formData.append("firstName", firstName.value);
	formData.append("lastName", lastName.value);
	formData.append("contactPhone", contactPhone.value);
	formData.append("contactEmail", contactEmail.value);
	formData.append("address1", address1.value);
	formData.append("address2", address2.value);
	formData.append("region", region[region.selectedIndex].value);
	formData.append("cityArea", cityArea.value);
	formData.append("city", city.value);
	formData.append("cityCode", cityCode.value);
	formData.append("isPrimary", isPrimary.checked);

	fetch(url, {
	method: 'POST',
	body: formData,
	})
	.then(response => response.text())
	.then(result => {
		if (result.includes("successfully")) {
			alert("Delivery insert successfully!");
			window.location.reload();
		}
	})
}
function getDeliveryDetail() {
	const url = address + 'get_delivery';
	const formData = new FormData();
	formData.append("userId", userId);

	fetch(url, {
		method: 'POST',
		body: formData,
	})
	.then(response => response.text())
	.then(result => {
		deliveryAddress.innerHTML = result;
	})
	.catch(error => {
		console.error('Error:', error);
	});	
}

function updateAddress(deliveryAddressGroup) {
	const firstNameDeliveryGroup = document.getElementById("firstNameDeliveryGroup" + deliveryAddressGroup);
	const lastNameDeliveryGroup = document.getElementById("lastNameDeliveryGroup" + deliveryAddressGroup);
	const contactPhoneDeliveryGroup = document.getElementById("contactPhoneDeliveryGroup" + deliveryAddressGroup);
	const contactEmailDeliveryGroup = document.getElementById("contactEmailDeliveryGroup" + deliveryAddressGroup);
	const address1DeliveryGroup = document.getElementById("address1DeliveryGroup" + deliveryAddressGroup);
	const address2DeliveryGroup = document.getElementById("address2DeliveryGroup" + deliveryAddressGroup);
	const cityAreaDeliveryGroup = document.getElementById("cityAreaDeliveryGroup" + deliveryAddressGroup);
	const regionDeliveryGroup = document.getElementById("regionDeliveryGroup" + deliveryAddressGroup);
	const cityDeliveryGroup = document.getElementById("cityDeliveryGroup" + deliveryAddressGroup);
	const cityCodeDeliveryGroup = document.getElementById("cityCodeDeliveryGroup" + deliveryAddressGroup);
	const isPrimaryDeliveryGroup = document.getElementById("isPrimaryDeliveryGroup" + deliveryAddressGroup);
	
	const url = address + 'update_delivery';
	const formData = new FormData();
	formData.append("userId", userId);
	formData.append("firstName", firstNameDeliveryGroup.value);
	formData.append("lastName", lastNameDeliveryGroup.value);
	formData.append("contactPhone", contactPhoneDeliveryGroup.value);
	formData.append("contactEmail", contactEmailDeliveryGroup.value);
	formData.append("address1", address1DeliveryGroup.value);
	formData.append("address2", address2DeliveryGroup.value);
	formData.append("region", regionDeliveryGroup[regionDeliveryGroup.selectedIndex].value);
	formData.append("cityArea", cityAreaDeliveryGroup.value);
	formData.append("city", cityDeliveryGroup.value);
	formData.append("cityCode", cityCodeDeliveryGroup.value);
	formData.append("isPrimary", isPrimaryDeliveryGroup.checked);
	formData.append("deliveryGroup", deliveryAddressGroup);
	
	fetch(url, {
		method: 'POST',
		body: formData,
	})
	.then(response => response.text())
	.then(result => {
		if (result.includes("successfully")) {
			alert("Delivery update successfully!");
			window.location.reload();
		}
	})
	.catch(error => {
		console.error('Error:', error);
	});	
}

getDeliveryDetail();