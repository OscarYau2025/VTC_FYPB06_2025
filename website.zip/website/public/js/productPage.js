let user_icon_url = 3;

const reviewMessage = document.getElementById("reviewMessage");
const reviewNum = document.getElementById("reviewNum");

function review() {
	
	let reviewSuccess = false;
	
	const url = address + 'insert_review';
	let formData = new FormData();
	formData.append("productId", productId);
	formData.append("userId", userId);
	formData.append("userName", userId);
	formData.append("userIconUrl", user_icon_url);
	formData.append("reviewMessage", reviewMessage.value);
	formData.append("isActive", "active");
	
	// Send the POST request
	fetch(url, {
	  method: 'POST',
	  body: formData, // No need for JSON.stringify when using FormData
	})
	  .then(response => {
		console.log('Response Code:', response.status); // Logs the response code
		if (response.status == 200){
			reviewSuccess = true;
		}
		return response.text();
	  })
	  .then(result => {
		if (reviewSuccess) {
			let reviewContent = reviewMessage.value;
			let textBefore;
			let textAfter;
			for (let i = 0; i < reviewContent.length; i++) {
				if (i % 30 == 0) {
					textBefore = reviewContent.substring(0, i);
					textAfter = reviewContent.substring(i);
					reviewContent = textBefore + "\n" + textAfter;
				}
			}
			
			document.getElementById("reviewGroup").innerHTML = `<div class="media mb-4">
				<img src="user_icon_url" alt="Image" class="img-fluid mr-3 mt-1" style="width: 45px;">
				<div class="media-body">
					<h6>John Doe<small> - <i>01 Jan 2045</i></small></h6>
					<div class="text-primary mb-2">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star-half-alt"></i>
						<i class="far fa-star"></i>
					</div>
					<p>${reviewContent}</p>

				</div>
			</div> ${document.getElementById("reviewGroup").innerHTML}`;
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
  });
}

function getReview() {
	const url = address + 'get_review';
	let formData = new FormData();
	formData.append("productId", productId);
	fetch(url, {
	  method: 'POST',
	  body: formData,
	})
	  .then(response => response.text())
	  .then(result => {
		 if (result == "") {
			document.getElementById("reviewGroup").innerHTML = "No comments? Left your review to this product";
		 }
		 else
			document.getElementById("reviewGroup").innerHTML = result;
	  })
	  .catch(error => {
		console.error('Error:', error);
	  });	  
}
getReview();

function addToCart() {
	const url = address + 'add_cartItem';
	let formData = new FormData();
	formData.append("productId", productId);
	formData.append("userId", userId);
	formData.append("quantity", document.getElementById("quantityNum").value);
	fetch(url, {
		method: 'POST',
		headers: {
			Authorization: `Bearer ${localStorage.getItem('accessToken')}`, // Example of token retrieval
		},
		body: formData,
	})
	.then(response => {
		return response.status;
	})
	.then(result => {
		console.log(result);
		if (result == 401 || result == 403) {
			openLoginPanel(true);
		}
		else if (result == 200)
			alert("Add item to cart successfully");		
	})
	.catch(error => {
		if (error.includes("401") || error.includes("403")) {
		}
		else {
			alert(error);
		}		
	});
}