<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
	
	<style>
	.img-fluid {
		width: 100% !important;
		height: auto !important;
		max-height: 410px !important;
		object-position: center !important;
		object-fit: fill !important;
	}
	</style>
</head>
<style>

</style>
<body>
    <!-- Topbar Start -->
	<section id="header">
	</section>

    <!-- Navbar Start -->
	<section id="indexNav">
		<div class="container-fluid mb-5">
			<div class="row border-top px-xl-5">
				<div class="col-lg-3">
					<a class="btn shadow-none d-flex align-items-center justify-content-between bg-primary text-white w-100" data-toggle="collapse" href="#navbar-vertical" style="height: 65px; margin-top: -1px; padding: 0 30px;">
						<h6 class="m-0">Categories</h6>
						<i class="fa fa-angle-down text-dark"></i>
					</a>
					<nav class="collapse show navbar navbar-vertical navbar-light align-items-start p-0 border border-top-0 border-bottom-0" id="navbar-vertical">
						
					</nav>
				</div>
				<div class="col-lg-9">
					<nav class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0">
						<label onclick="openurl('index.php')" class="text-decoration-none d-block d-lg-none">

						</label>
						<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
							<span class="navbar-toggler-icon"></span>
						</button>
						<div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
							<div class="navbar-nav mr-auto py-0">
								<a href="index.php" class="nav-item nav-link active">Home</a>
								<a href="shop.html" class="nav-item nav-link">Shop</a>
								<div class="nav-item dropdown">
									<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Pages</a>
									<div class="dropdown-menu rounded-0 m-0">
										<a href="cart.html" class="dropdown-item">Shopping Cart</a>
                                    <a href="userCenter.html" class="dropdown-item">User Center</a>
									</div>
								</div>
								<a href="contact.html" class="nav-item nav-link">Contact</a>
							</div>
							<div class="navbar-nav ml-auto py-0" id="userActionArea">
							</div>
						</div>
					</nav>
					<div id="header-carousel" class="carousel slide" data-ride="carousel" >
						<div class="carousel-inner" id="homeCarousel">
						</div>
						<a class="carousel-control-prev" href="#header-carousel" data-slide="prev">
							<div class="btn btn-dark" style="width: 45px; height: 45px;">
								<span class="carousel-control-prev-icon mb-n2"></span>
							</div>
						</a>
						<a class="carousel-control-next" href="#header-carousel" data-slide="next">
							<div class="btn btn-dark" style="width: 45px; height: 45px;">
								<span class="carousel-control-next-icon mb-n2"></span>
							</div>
						</a>
					</div>
				</div>
			</div>
		</div>
	</section>
    <!-- Navbar End -->


    <!-- Featured Start -->
    <div class="container-fluid pt-5">
        <div class="row px-xl-5 pb-3">
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="d-flex align-items-center border mb-4" style="padding: 30px;" onclick="window.location.href='qualityProduct.html'">
                    <h1 class="fa fa-check text-primary m-0 mr-3"></h1>
                    <h5 class="font-weight-semi-bold m-0">Quality Product</h5>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="d-flex align-items-center border mb-4" style="padding: 30px;" onclick="window.location.href='shipping.html'">
                    <h1 class="fa fa-shipping-fast text-primary m-0 mr-2"></h1>
                    <h5 class="font-weight-semi-bold m-0">Shipping Anywhere within Hong Kong</h5>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="d-flex align-items-center border mb-4" style="padding: 30px;" onclick="window.location.href='reasonableReturn.html'">
                    <h1 class="fas fa-exchange-alt text-primary m-0 mr-3"></h1>
                    <h5 class="font-weight-semi-bold m-0">Reasonable Return</a></h5>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="d-flex align-items-center border mb-4" style="padding: 30px;" onclick="window.location.href='contact.html'">
                    <h1 class="fa fa-phone-volume text-primary m-0 mr-3"></h1>
                    <h5 class="font-weight-semi-bold m-0">24/7 Support</h5>
                </div>
            </div>
        </div>
    </div>
    <!-- Featured End -->


    <!-- Footer Start -->
    <section id="footer">	
	</section>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
	<script src="js/globalFunction.js"></script>
	<script src="js/home.js"></script>
</body>
</html>