getCategorie();
let action = "insert";
let data = {
  action: "delete",
  categorieId: -1
};;

function updateCategorie(data, method) {
	const url = address + method;
	
	fetch(url, {
	  method: 'POST',
	  headers: {
		'Content-Type': 'application/json'
	  },
	  body: JSON.stringify(data)
	})
	  .then(response => {
			if (response.status == 400) {
				alert("Please full up all the input field");
			}
			return response.text();
		})
	  .then(result => {
console.log(result);
		if (result.includes("successfully")) {
			alert(data.action + " categorie successfully");
			window.location.reload();
		}
	  })
	  .catch(error => {

	  });
}

function getCategorie() {	
	const url = address + 'get_categorie';

	fetch(url, {
	  method: 'POST',
	  headers: {
		'Content-Type': 'application/json'
	  },
	  body: JSON.stringify({action:"categorie"}),
	})
	  .then(response => response.text())
	  .then(result => {
		document.getElementById("parentCategorie").innerHTML = '<option id="-1">NONE</option>' + result;
		document.getElementById("deleteCategorie").innerHTML = '<option id="-1">NONE</option>' + result;
		document.getElementById("updateCategorie").innerHTML = '<option id="-1">NONE</option>' + result;
	  })
	  .catch(error => {
		console.error('Error:', error);
	  });	  
}

function radioButton(actions) {
	if (actions == "insert")
		document.getElementById("updateCategorie").disabled = true;
	else if (actions == "update")
		document.getElementById("updateCategorie").disabled = false;
	
	action = actions;
}

function createButtonHandler() {
	if (action == "insert") {
		const categorieName = document.getElementById("categorieName").value;
		const parentCategorie = document.getElementById("parentCategorie")[document.getElementById("parentCategorie").selectedIndex].id;
		const categorieDescription = document.getElementById("categorieDescription").value;

		data = {
		  admin: userId,
		  action: action,
		  categorieName: categorieName,
		  parentCategorie: parentCategorie,
		  categorieDescription: categorieDescription
		};
		updateCategorie(data, "create_categorie");
	}
	else if (action == "update") {
		const categorieId = document.getElementById("updateCategorie")[document.getElementById("updateCategorie").selectedIndex].id;
		const categorieName = document.getElementById("categorieName").value;
		const parentCategorie = document.getElementById("parentCategorie")[document.getElementById("parentCategorie").selectedIndex].id;
		const categorieDescription = document.getElementById("categorieDescription").value;

		if (categorieId == parentCategorie && categorieId != -1) {
			alert("Can't set self as parent");
			return;
		}
		if (categorieId == -1) {
			alert("Please select a categorie to update");
			return;
		}

		data = {
		  admin: userId,
		  action: action,
		  categorieId: categorieId,
		  categorieName: categorieName,
		  parentCategorie: parentCategorie,
		  categorieDescription: categorieDescription
		};
		updateCategorie(data, "update_categorie");
	}
}

function deleteButtonHandler() {
	if (document.getElementById("deleteCategorie")[document.getElementById("deleteCategorie").selectedIndex].id == -1) {
		alert("Please select a categorie to delete");
		return;
	}
	
	data = {
	  admin: userId,
	  action: 'delete',
	  categorieId: document.getElementById("deleteCategorie")[document.getElementById("deleteCategorie").selectedIndex].id
	};
	updateCategorie(data, "delete_categorie");
}
/*<script src="https://cdn.socket.io/4.8.1/socket.io.min.js" integrity="sha384-mkQ3/7FUtcGyoppY6bz/PORYoGqOl7/aSUMn2ymDOJcapfS6PHqxhRTMh1RR0Q6+" crossorigin="anonymous"></script>
const socket = io();
socket.emit("message", 123);*/