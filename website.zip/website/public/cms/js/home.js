function viewChart(date) {
	document.getElementById("dailyVisit").height = 120;
	document.getElementById("dailyVisit").width = 120;

	const formData = new FormData();
	formData.append("unique", false);
	formData.append("page", 'all');
	formData.append("date", date);

	fetch(address + 'get_page_view', {
		method: "POST",
		body: formData
	})
	.then(response => response.json()) // Read response as text
	.then(data => {
		const pageVisitDate = document.getElementById("pageVisitDate").value;
		document.getElementById("dataIcon").innerHTML = "";
		
		let doughnutData = [];
		let allViewCount = 0;

		for (let i = 0; i < data.length; i++) {
			allViewCount += parseInt(data[i].views);
		}

		document.getElementById("dataIcon").innerHTML += `<div class="col-sm-12 col-xs-12 goleft" style="float: left;">
																<p><i style="width: 100px; height: 100px; margin-right: 20px; color:gray;">All page views: ${allViewCount} (${pageVisitDate})</i></p>
															</div>`;
		for (let i = 0; i < data.length; i++) {
			const randomColor = '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
			
			while (doughnutData.some(entry => entry.color === randomColor) || randomColor.toLowerCase() === "#000000") {
				randomColor = '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
			}
			
			document.getElementById("dataIcon").innerHTML += `<div class="col-sm-12 col-xs-12 goleft" style="float: left;">
																<p><i style="width: 100px; height: 100px; background-color: ${randomColor}; border: 2px solid ${randomColor}; margin-right: 20px;"></i>${data[i].page_url.replace("EShopper-Tool Shop ", "")} views: ${data[i].views}</p>
															</div>`;
			doughnutData.push({value: data[i].views, color:randomColor});
		}
		myDoughnut = new Chart(document.getElementById("dailyVisit").getContext("2d")).Doughnut(doughnutData);
	});
}

function visitDateOnchange(element) {
	const fromDateInput = document.getElementById("visitFromDate");
	const toDateInput = document.getElementById("visitToDate");

	const fromDate = new Date(fromDateInput.value);
	const toDate = new Date(toDateInput.value);

	if (!fromDateInput.value || !toDateInput.value) {
		return;
	}
	let today = new Date();

	if (fromDate >= toDate) {
		if (event.target === toDateInput) {
			toDateInput.value = null;
		} else if (event.target === fromDateInput) {
			fromDateInput.value = null;
		}
	}
}

function gettingTopProduct(date) {
	
	const formData = new FormData();
	formData.append("date", date);

	fetch(address + 'getTopProduct', {
		method: "POST",
		body: formData
	})
	.then(response => response.json()) // Read response as text
	.then(data => {

		if (!data || data.length <= 0) {
			document.getElementById("topProductImage").src = ``;
			document.getElementById("topProductContent").innerHTML = ``;
			return;
		}

		const topProduct = data.reduce((max, record) => record.totalQuantity > max.totalQuantity ? record : max, data[0]);

		document.getElementById("topProductImage").src = `${siteLink.replace("cms/", "")}${topProduct.product_display_image_url}`;
		document.getElementById("topProductContent").innerHTML = `<br>
											<p>${topProduct.product_name}</p>
											<p><a href="${topProduct.product_url}" target="_blank"><u>PRODUCT URL</u></a></p>
											<p>${topProduct.newDate}</p>
											<p><b style="color:#999999;">Total sold ${topProduct.totalQuantity}</b></p>`;
	});
}

function visitChart(dateA, dateB, type) {
	
	const formData = new FormData();
	formData.append("dateA", dateA);
	formData.append("dateB", dateB);
	formData.append("type", type);

	fetch(address + 'get_data_by_date', {
		method: "POST",
		body: formData
	})
	.then(response => response.json()) // Read response as text
	.then(data => {

		if (!data || data.length <= 0)
			return;
		
		if (type == "pageView")
			gettingPageView(data);
		else if (type == "revenue")
			gettingRevenue(data);
		else if (type == "user")
			gettingUserNum(data);
		
		$('.tooltips').tooltip();
		if ($(".custom-bar-chart")) {
			$(".bar").each(function () {
				var i = $(this).find(".value").html();
				$(this).find(".value").animate({
					height: i
				}, 500)
			})
		}

	});
}

function gettingPageView(data) {
	let axisY = `<ul class="y-axis">`;
	let axisX = ``;
	
	const totalViewsSum = data.reduce((sum, record) => sum + record.total_views, 0);
	const mostViewedMonth = data.reduce((max, record) => record.total_views > max.total_views ? record : max, data[0]);

	for (let i = 5; i >= 0; i--) {
		axisY += `<li><span>${(roundUpToNearest(mostViewedMonth.total_views) / 5 * i)}</span></li>`;
	}
	axisY += `</ul>`;
	
	for (let i = 0; i < data.length; i++) {
		const pensentage = Math.ceil(data[i].total_views * 100 / totalViewsSum);
		axisX += `<div class="bar">
					  <div class="title">${data[i].new_view_date}</div>
					  <div class="value tooltips" data-original-title="${data[i].total_views} (${pensentage}%)" data-toggle="tooltip" data-placement="top">${pensentage}%</div>
				  </div>`;
	}
	document.getElementById("visitChart").innerHTML = "";
	document.getElementById("visitChart").innerHTML = axisY;
	document.getElementById("visitChart").innerHTML += axisX;
}

function gettingUserNum(data) {
	let axisY = `<ul class="y-axis">`;
	let axisX = ``;

	const totalViewsSum = data.reduce((sum, record) => sum + record.total_amount, 0);
	const mostViewedMonth = data.reduce((max, record) => record.total_amount > max.total_amount ? record : max, data[0]);
	
	for (let i = 5; i >= 0; i--) {
		axisY += `<li><span>${(roundUpToNearest(mostViewedMonth.total_amount) / 5 * i).toFixed(2)}</span></li>`;
	}
	axisY += `</ul>`;
	
	for (let i = 0; i < data.length; i++) {
		const pensentage = Math.ceil(data[i].total_amount * 100 / totalViewsSum);
		axisX += `<div class="bar">
					  <div class="title">${data[i].new_create_date}</div>
					  <div class="value tooltips" data-original-title="${data[i].total_amount} (${pensentage}%)" data-toggle="tooltip" data-placement="top">${pensentage}%</div>
				  </div>`;
	}
	document.getElementById("visitChart").innerHTML = "";
	document.getElementById("visitChart").innerHTML = axisY;
	document.getElementById("visitChart").innerHTML += axisX;
}

function gettingRevenue(data) {
	let axisY = `<ul class="y-axis">`;
	let axisX = ``;
	
	const totalSum = data.reduce((sum, record) => sum + record.total_amount, 0);
	const mostViewedMonth = data.reduce((max, record) => record.total_amount > max.total_amount ? record : max, data[0]);

	for (let i = 5; i >= 0; i--) {
		axisY += `<li><span>${(roundUpToNearest(mostViewedMonth.total_amount) / 5 * i).toFixed(2)}</span></li>`;
	}
	axisY += `</ul>`;
	
	for (let i = 0; i < data.length; i++) {
		const pensentage = Math.ceil(data[i].total_amount * 100 / totalSum);
		axisX += `<div class="bar">
					  <div class="title">${data[i].new_transaction_date}</div>
					  <div class="value tooltips" data-original-title="$${data[i].total_amount} (${pensentage}%)" data-toggle="tooltip" data-placement="top">${pensentage}%</div>
				  </div>`;
	}
	document.getElementById("visitChart").innerHTML = "";
	document.getElementById("visitChart").innerHTML = axisY;
	document.getElementById("visitChart").innerHTML += axisX;
}

function prepareToVisitChart(dateA, dateB, type) {
	if (!dateA || !dateB || !type)
		return;
	
	dateA += -01;
	dateB += -01;
	
	visitChart(dateA, dateB, type);
}

function getNearestMultiple(value) {
    let length = value.toString().length; // Get the number of digits
    let nearestMultiple = Math.pow(10, length - 1); // Generate a power of 10 based on digits
    return nearestMultiple;
}

function roundUpToNearest(value) {
    let nearest = getNearestMultiple(value);
	const number = Math.ceil(value / nearest) * nearest;
	
	if (number < 10)
		return number;
	else 
		return number;
}

function dateFormatting(withTime, addMonth) {
	let dateTime = new Date();
	dateTime.setMonth(dateTime.getMonth() + addMonth);
	
	dateTime = dateTime.toLocaleDateString("en-CA", { timeZone: "Asia/Hong_Kong" });
	
	if (withTime)
		return dateTime;
	else
		return dateTime.toString().split(",")[0].replaceAll("/", "-");
}
const dateTime = new Date();
const hongKongTime = dateTime.toLocaleDateString("en-CA", { timeZone: "Asia/Hong_Kong" });
const today = hongKongTime.split(",")[0].replaceAll("/", "-");
document.getElementById("pageVisitDate").value = today;


viewChart(dateFormatting(false, 0));
gettingTopProduct(dateFormatting(false, 0));
visitChart(dateFormatting(false, -5), dateFormatting(false, 0), "pageView");
