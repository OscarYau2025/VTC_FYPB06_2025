const emailInput = document.getElementById("emailInput");
const adminRoleSelection = document.getElementById("adminRoleSelection");
const adminNameInput = document.getElementById("adminNameInput");
const passwordInput = document.getElementById("passwordInput");
const confirmPasswordInput = document.getElementById("confirmPasswordInput");
const isActiveChecbox = document.getElementById("isActiveCheckbox");

const roleSelection = document.getElementById("roleSelection");
const roleNameInput = document.getElementById("roleNameInput");
const roleDescriptionInput = document.getElementById("roleDescriptionInput");

function confirmAdminClick() {
	if (emailInput.value.trim() == null || adminNameInput.value.trim() == null || passwordInput.value.trim() == null || roleSelection.selectedIndex == -1) {
		alert("Please fill all the field");
		return;
	}
	else if (passwordInput.value != confirmPasswordInput.value) {
		alert("Password not match");
		return;
	}
	createAdmin();
}

function confirmRoleClick() {
	if (roleNameInput.value.trim() == null || roleDescriptionInput.value.trim() == null) {
		alert("Please fill all the field");
		return;
	}
	createRole();
}

function createAdmin() {
	const url = address + 'create_admin';

	let formData = new FormData();
	formData.append("admin", userId);
	formData.append("name", adminNameInput.value);
	formData.append("email", emailInput.value);
	formData.append("adminPassword", passwordInput.value);
	formData.append("roleId", adminRoleSelection[adminRoleSelection.selectedIndex].id);
	formData.append("isActive", isActiveChecbox.checked);

	fetch(url, {
	  method: 'POST',
	  body: formData, // No need for JSON.stringify when using FormData
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		if (result.includes("successfully")) {
			alert("Admin created successfully");
			window.location.reload(true);
		}
		else
			alert("Email or Admin id exist, please change email address or click 'create' button again");
	  })
	  .catch(error => {
		console.error('Error:', error);
    });
}

function createRole() {
	
	const url = address + 'create_role';
	let formData = new FormData();
	formData.append("admin", userId);
	formData.append("name", roleNameInput.value);
	formData.append("description", roleDescriptionInput.value);
	
	// Send the POST request
	fetch(url, {
	  method: 'POST',
	  body: formData, // No need for JSON.stringify when using FormData
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		console.log(result);
		if (result.includes("successfully")) {
			alert("Role created successfully");
			window.location.reload(true);
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
  });
}

function deleteAdmin() {
	
	const url = address + 'delete_admin';
	let formData = new FormData();
	formData.append("operatedAdmin", userId);
	formData.append("adminId", adminSelection[adminSelection.selectedIndex].id);
	
	// Send the POST request
	fetch(url, {
	  method: 'POST',
	  body: formData, // No need for JSON.stringify when using FormData
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		  if (result.includes("successfully")) {
			alert("Admin delete successfully");
			window.location.reload(true);
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
  });
}

function deleteRole() {
	
	const url = address + 'delete_role';
	let formData = new FormData();
	formData.append("admin", userId);
	formData.append("roleId", roleSelection[roleSelection.selectedIndex].id);
	
	// Send the POST request
	fetch(url, {
	  method: 'POST',
	  body: formData, // No need for JSON.stringify when using FormData
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		console.log(result);
		if (result.includes("successfully")) {
			alert("Role delete successfully");
			window.location.reload(true);
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
  });
}

function get_role() {
	const url = address + 'get_role';
	
	// Send the POST request
	fetch(url, {
	  method: 'post',
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		  roleSelection.innerHTML = result;
			adminRoleSelection.innerHTML = result;
		  
	  })
	  .catch(error => {
		console.error('Error:', error);
  });
}

function get_admin() {
	const url = address + 'get_admin';
	// Send the POST request
	fetch(url, {
	  method: 'post',
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		document.getElementById("adminSelection").innerHTML = result;
	  })
	  .catch(error => {
		console.error('Error:', error);
  });
}
get_role();
get_admin();