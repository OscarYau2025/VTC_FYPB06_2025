const address = 'http://localhost:8080/';
const siteLink = 'http://localhost/website/public/cms/';
//const address = 'https://toolshop.sadnovice.com:8080/';
//const siteLink = 'https://toolshop.sadnovice.com/cms/';

const pageTitle = "Admin Console - ";
const userId = localStorage.getItem("adminId");

let componentAry = ["header", "footer", "sidebar"];
Promise.all(
  componentAry.map(async (component) => {
    const element = document.getElementById(component);
    if (element) {
      try {
        const response = await fetch(siteLink + "component/" + component + ".html");
        if (!response.ok) throw new Error("Failed to load " + component);
        const data = await response.text();
        element.innerHTML = data;
      } catch (error) {
        console.error(error);
      }
    }
  })
).then(() => {
  
});

if (window.location.href.includes(siteLink + "index.html"))
	document.title = pageTitle + "Home Page";
else if (window.location.href.includes(siteLink + "productManagement.html"))
	document.title = pageTitle + "Product";
else if (window.location.href.includes(siteLink + "categoriesManagement.html"))
	document.title = pageTitle + "Categories";
else if (window.location.href.includes(siteLink + "adminAndRoleManagement.html"))
	document.title = pageTitle + "Admin and Role";
else if (window.location.href.includes(siteLink + "couponManagement.html"))
	document.title = pageTitle + "Coupon";
else if (window.location.href.includes(siteLink + "userManagement"))
	document.title = pageTitle + "User";
else if (window.location.href.includes(siteLink + "refundAndReturnManagement.html"))
	document.title = pageTitle + "Refund and Return";
else if (window.location.href.includes(siteLink + "reviewManagement.html"))
	document.title = pageTitle + "Review";
else if (window.location.href.includes(siteLink + "orderManagement.html"))
	document.title = pageTitle + "Order";
else if (window.location.href.includes(siteLink + "secuityQuestionManagement.html"))
	document.title = pageTitle + "Security Question";
else if (window.location.href.includes(siteLink + "homeImageManagement.html"))
	document.title = pageTitle + "Home Image";
else if (window.location.href.includes(siteLink + "login.html"))
	document.title = pageTitle + "Login";

async function login(username, password) {
  try {
    const loginEmail = document.getElementById("loginEmail").value;
    const loginPassword = document.getElementById("loginPassword").value;

    const response = await fetch(`${address}adminLogin`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userEmail: loginEmail, password: loginPassword }), // Send JSON
    });

    const data = await response.json();

	if (response.status == 200) {
		localStorage.setItem('adminAccessToken', data.adminAccessToken);
		localStorage.setItem('adminRefreshToken', data.adminRefreshToken);
		localStorage.setItem('adminId', data.result);
		window.location.href = siteLink + "index.html";
	}
	else {
		document.getElementById("loginErrorMessage").innerHTML = "Invalid email or password";
	}
  } catch (err) {
    console.error('Error:', err);
  }
}

async function accessProtectedRoute() {
  try {
    const adminAccessToken = localStorage.getItem('adminAccessToken');
    const adminRefreshToken = localStorage.getItem('adminRefreshToken');

    if (!adminAccessToken || !adminRefreshToken) {
      console.error('Missing tokens: Please log in again.');
	  logout();
      return false;
    }

    const response = await fetch(`${address}adminProtected`, {
      method: 'GET',
      headers: {
        Authorization: adminAccessToken,
        'x-refresh-token': adminRefreshToken,
      },
    });

    // Handle response headers for refreshed tokens
    if (response.headers.get('Authorization') && response.headers.get('x-refresh-token')) {
      const newAccessToken = response.headers.get('Authorization');
      const newRefreshToken = response.headers.get('x-refresh-token');

      // Update stored tokens
      localStorage.setItem('adminAccessToken', newAccessToken);
      localStorage.setItem('adminRefreshToken', newRefreshToken);
    }

    if (response.ok) {
      const data = await response.json();
	  return true;
    } else {
      // Handle unauthorized or failed access
      if (response.status === 401) {
        console.error('Access denied: Token expired or invalid.');
      } else {
        console.error(`Access denied: ${response.statusText}`);
      }
		return false;
    }
  } catch (err) {
    console.error('Error occurred while accessing protected route:', err.message || err);
	return false;
  }
}

function logout() {
	fetch(address + 'logout', {
		method: 'POST',
		headers: {
			'Authorization': localStorage.getItem('adminAccessToken'),
			'Content-Type': 'application/json'
		}
	})
	.then(response => {
		return response.text();
	})
	.then(data => {})
	.catch(error => console.error('Error:', error));
	
  localStorage.removeItem('adminAccessToken');
  localStorage.removeItem('adminRefreshToken');
  localStorage.removeItem('adminId');
  if (!window.location.href.includes(siteLink + "login.html"))
	window.location.href = siteLink + "login.html";
}

accessProtectedRoute().then(logined => {
    redirect(logined);
}).catch(error => {
    console.error(error);
	redirect(false);
});

function redirect(logined) {
	if (logined == true) {
		if (window.location.href.includes(siteLink + "login.html"))
			window.location.href = siteLink + "index.html";
	}
	else if (logined == false)
		if (!window.location.href.includes(siteLink + "login.html"))
			window.location.href = siteLink + "login.html";
}
