const securityQuestionContentInput = document.getElementById("securityQuestionContentInput");

const securityQuestionSelection = document.getElementById("securityQuestionSelection");

function confirmRoleClick() {
	if (roleNameInput.value.trim() == null || roleDescriptionInput.value.trim() == null) {
		alert("Please fill all the field");
		return;
	}
	createRole();
}

function createSecurityQuestion() {
	const url = address + 'create_SecurityQuestion';

	let formData = new FormData();
	formData.append("admin", userId);
	formData.append("securityQuestionContentInput", securityQuestionContentInput.value);

	fetch(url, {
	  method: 'POST',
	  body: formData, // No need for JSON.stringify when using FormData
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		console.log(result);
		if (result.includes("successfully")) {
			alert("Security Question created successfully");
			window.location.reload(true);
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
    });
}

function deleteSecurityQuestion() {
	
	const url = address + 'delete_securityQuestion';
	let formData = new FormData();
	formData.append("admin", userId);
	formData.append("securityQuestionId", securityQuestionSelection[securityQuestionSelection.selectedIndex].id);
	
	// Send the POST request
	fetch(url, {
	  method: 'POST',
	  body: formData, // No need for JSON.stringify when using FormData
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		  if (result.includes("successfully")) {
			alert("Security Question delete successfully");
			window.location.reload(true);
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
  });
}

function get_SecurityQuestion() {
	const url = address + 'get_securityQuestion';
	
	// Send the POST request
	fetch(url, {
	  method: 'post',
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		  securityQuestionSelection.innerHTML = result;
	  })
	  .catch(error => {
		console.error('Error:', error);
  });
}

get_SecurityQuestion();