const orderId = document.getElementById("orderId");
const orderId2 = document.getElementById("orderId2");
const couponId = document.getElementById("couponId");
const totalAmount = document.getElementById("totalAmount");
const orderStatus = document.getElementById("orderStatus");
const createDate = document.getElementById("createDate");
const lastUpdate = document.getElementById("lastUpdate");

function confirmOrderClick() {
	const url = address + 'adminUpdateOrder';

	let formData = new FormData();
	formData.append("admin", userId);
	formData.append("orderId", orderId[orderId.selectedIndex].id);
	formData.append("totalAmount", totalAmount.value);
	formData.append("orderStatus", orderStatus[orderStatus.selectedIndex].dataset.name);
	
	fetch(url, {
	  method: 'POST',
	  body: formData, // No need for JSON.stringify when using FormData
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		if (result.includes("successfully")) {
			alert("Order update successfully");
			window.location.reload(true);
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
    });
}

function deleteOrderClick() {
	const url = address + 'adminDeleteOrder';

	let formData = new FormData();
	formData.append("admin", userId);
	formData.append("orderId", orderId2[orderId2.selectedIndex].id);

	fetch(url, {
	  method: 'POST',
	  body: formData, // No need for JSON.stringify when using FormData
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		if (result.includes("successfully")) {
			alert("Order delete successfully");
			window.location.reload(true);
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
    });
}

function getOrderId() {
	const url = address + 'adminGetOrder';
	
	fetch(url, {
	  method: 'POST',
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		if (result != "") {
			orderId.innerHTML = result;
			orderId2.innerHTML = result;
			onChangeForm();
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
    });
}

function onChangeForm() {
	couponId.value = orderId[orderId.selectedIndex].coupon_id;
	totalAmount.value = orderId[orderId.selectedIndex].dataset.total_amount;
	createDate.value = orderId[orderId.selectedIndex].dataset.create_at;
	lastUpdate.value = orderId[orderId.selectedIndex].dataset.update_at;
	orderStatus.selectedIndex = findStatus(orderId[orderId.selectedIndex].dataset.order_status);
}

function findStatus(index) {
	for(let i = 0; i < orderStatus.length; i++) {
		if (index == orderStatus[i].dataset.name) {
			return i;
		}
	}
	return 0; 
}

getOrderId();