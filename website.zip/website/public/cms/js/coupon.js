const couponNameInput = document.getElementById("couponNameInput");
const couponDescriptionInput = document.getElementById("couponDescriptionInput");

const percentageOptions = document.getElementById("percentageOptions");
const actualAmountOptions = document.getElementById("actualAmountOptions");
const percentage = document.getElementById("percentage");
const actualAmount = document.getElementById("actualAmount");

const couponUageLimit = document.getElementById("couponUageLimit");
const couponUageLimitFile = document.getElementById("couponUageLimitFile");
const targetSelection = document.getElementById("targetSelection");
const couponExpirationDate = document.getElementById("couponExpirationDate");
const couponSelection = document.getElementById("couponSelection");

function confirmCouponClick() {
	let type = "";
	let discount = 0;
	if (percentageOptions.checked) {
		type = "persentage";
		discount = percentage.value;
	}
	else {
		type = "amount";
		discount = actualAmount.value;
	}
	
	if (discount < 1) {
		alert("Discount value must bigger that 0");
	}
	else {
		const url = address + 'create_coupon';
		let formData = new FormData();
		formData.append("userId", userId);
		formData.append("couponTarget", targetSelection.value);
		formData.append("name", couponNameInput.value);
		formData.append("description", couponDescriptionInput.value);
		formData.append("couponType", type);
		formData.append("discountAmount", discount);
		formData.append("couponUsageLimit", couponUageLimit.value);
		formData.append("expirationDate", couponExpirationDate.value);
		formData.append("couponImage", couponUageLimitFile.files[0]);

		fetch(url, {
			method: 'POST',
			body: formData,
		})
		.then(response => {
			// Check if the response is OK (status in the range 200-299)
			if (response.status == 400) {
				throw new Error(`Please fill in all the input field`);
			}
			else if (response.status == 500) {
				throw new Error("Opps~! Encounter unknown situation, please refresh page and try again later.");
			}
			else if (response.status == 200) {
				alert("Coupon added successfully");
				window.location.reload();
			}
			
			// Pass the text value to the next .then() block
			return response.text();
		})
		.then(result => {
			
		})
		.catch(error => {
			alert(error);
		});
	}
}

function getCoupon() {

	const url = address + 'getCoupon';
	fetch(url, {
		method: 'POST',

	})
	.then(response => {

		return response.text();
	})
	.then(result => {
		couponSelection.innerHTML = result;
	})
	.catch(error => {
		alert(error);
	});
}

function deleteCoupon() {
	const url = address + 'deleteCoupon';
	let formData = new FormData();
	formData.append("userId", userId);
	formData.append("coupon", couponSelection.value);

	if (couponSelection.value == "" || !couponSelection.value) {
		alert("No coupon selected");
		return;
	}

	fetch(url, {
		method: 'POST',
		body: formData,
	})
	.then(response => {		

			if (response.status == 500) {
				throw new Error("Opps~! Encounter unknown situation, please refresh page and try again later.");
			}
			else if (response.status == 200) {
				alert("Coupon delete successfully");
				window.location.reload();
			}
			
		return response.text();
	})
	.then(result => {

	})
	.catch(error => {
		alert(error);
	});
}
getCoupon();