document.getElementById("loginButton").addEventListener("click", function(event) {
    event.preventDefault(); // Prevent default action (e.g., form submission)
	login(); // Call the login function

});
document.addEventListener("keydown", function(event) {
    // Check if the pressed key is "Enter"
    if (event.key === "Enter") {
        event.preventDefault(); // Prevent default behavior, like form submission
        // Check if the currently focused element matches the email or password input fields
        if (document.activeElement === document.getElementById("loginEmail") || document.activeElement === document.getElementById("loginPassword")) {
            login(); // Call the login function
        }
    }
});