getCategorie();

const productDetailTextarea = document.getElementById("product_detail");
let cursorPosition = 0;
let detailFile = [];
let iconFile = [];

const productName = document.getElementById("product_name");
const productPrice = document.getElementById("product_price");
const parentCategorie = document.getElementById("parentCategorie");
const subCategories = document.getElementById("subCategories");
const stockLevel = document.getElementById("stock_level");
const productDescription = document.getElementById("product_description");
let productDetail = document.getElementById("product_detail");
const productDesplayIconUpload = document.getElementById("productDesplayIconUpload");
const productImageUpload = document.getElementById("productImageUpload");

const productOptionList = document.getElementById("productOptionList");
const product_name2 = document.getElementById("product_name2");
const product_price2 = document.getElementById("product_price2");
const stock_level2 = document.getElementById("stock_level2");
const product_description2 = document.getElementById("product_description2");
const parentCategorie2 = document.getElementById("parentCategorie2");

// Event listener to detect cursor position on input or click
productDetailTextarea.addEventListener("input", () => {cursorPosition = productDetailTextarea.selectionStart});
productDetailTextarea.addEventListener("click", () => {cursorPosition = productDetailTextarea.selectionStart});

function createProduct() {
	const randomUrl = generateRandomString(40);
	
	productDetail.value = productDetail.value.replaceAll("\n", "<br>");
	productDescription.value = productDescription.value.replaceAll("\n", "<br>");
	
	const url = address + 'create_product';
	let formData = new FormData();
	formData.append("admin", userId);
	formData.append("name", productName.value);
	formData.append("price", productPrice.value);
	formData.append("description", productDescription.value);
	formData.append("detail", productDetail.value);
	formData.append("parentCategorie", parentCategorie[parentCategorie.selectedIndex].id);
	formData.append("subCategories", subCategories);
	formData.append("stockLevel", stockLevel.value);
	formData.append("url", randomUrl);
	
	for (let i = 0; i < productDesplayIconUpload.files.length; i++) {		
		formData.append("productDesplayIconNames", generateRandomString(10) + "_" + productDesplayIconUpload.files[i].name); // Append image name
		formData.append("productDesplayIcon", productDesplayIconUpload.files[i]); // Append image file
	}
	
	detailFile.forEach(([imagename, imagefile]) => {
		formData.append("detailFileNames", imagename); // Append image name
		formData.append("detailFiles", imagefile); // Append image file
	});

	// Send the POST request
	fetch(url, {
	  method: 'POST',
	  body: formData, // No need for JSON.stringify when using FormData
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		if (result.includes("successfully")) {
			alert("Product created successfully");
			window.location.reload();
		}
		else {
			alert("Please provide the full body");
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
	  });
}

//admin, product_id, product_name, product_price, product_description, categories_id, stock_level
function adminUpdateProduct() {
	product_description2.value = product_description2.value.replaceAll("\n", "<br>");
	
	const url = address + 'adminUpdateProduct';
	
	let formData = new FormData();
	formData.append("admin", userId);
	formData.append("product_id", productOptionList.value);
	formData.append("product_name", product_name2.value);
	formData.append("product_price", product_price2.value);
	formData.append("product_description", product_description2.value);
	formData.append("categories_id", parentCategorie2[parentCategorie2.selectedIndex].id);
	formData.append("stockLevel", stock_level2.value);

	// Send the POST request
	fetch(url, {
	  method: 'POST',                   // HTTP method
	  headers: {
		'Content-Type': 'application/json' // Specify JSON format
	  },
	  body: formData       // Convert the data to a JSON string
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		if (result.includes("successfully")) {
			alert("Update product successfully");
			window.location.reload();
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
	  });
}

function deleteProduct() {
	const url = address + 'admin_deleteProduct';
	const data = {
	  admin: userId,
	  product: productOptionList[productOptionList.selectedIndex].id,
	};

	// Send the POST request
	fetch(url, {
	  method: 'POST',                   // HTTP method
	  headers: {
		'Content-Type': 'application/json' // Specify JSON format
	  },
	  body: JSON.stringify(data)       // Convert the data to a JSON string
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		if (result.includes("successfully")) {
			alert("delete product successfully");
			window.location.reload();
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
	  });
}

function getProduct() {
	const url = address + 'admin_GetProduct';
	// Send the POST request
	fetch(url, {
	  method: 'POST',                   // HTTP method
	  headers: {
		'Content-Type': 'application/json' // Specify JSON format
	  },
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
			if (result != "") {
			  productOptionList.innerHTML = result;
			  productOptionList2.innerHTML = result;
			  onChangeUpdateProduct();
			}
	  })
	  .catch(error => {
		console.error('Error:', error);
	  });
}
getProduct();

function generateRandomString(length) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    result += characters[randomIndex];
  }
  return result;
}

function getCategorie() {	
	const url = address + 'get_categorie';

	fetch(url, {
	  method: 'POST',
	  headers: {
		'Content-Type': 'application/json'
	  },
	  body: JSON.stringify({action:"product"}),
	})
	  .then(response => response.text())
	  .then(result => {
		document.getElementById("parentCategorie").innerHTML = result.split("|")[0];
		document.getElementById("parentCategorie2").innerHTML = result.split("|")[0];
		document.getElementById("subCategorie").innerHTML = '<option id="-1">NONE</option>' + result.split(":")[1];
	  })
	  .catch(error => {
		console.error('Error:', error);
	  });	  
}

function onProductDetailImageUploaded(event) {
	const productDetail = document.getElementById("product_detail");
	const productImageUpload = document.getElementById("productImageUpload");
	let textBefore = productDetail.value.substring(0, cursorPosition);
	let textAfter = productDetail.value.substring(cursorPosition);
	
	
	for (let i = 0; i < detailFile.length; i++) {
		productDetail.value = productDetail.value.replace("(img){" + detailFile[i][0] + "}", "");
	}
	
	detailFile = [];
	
	for (let i = 0; i < productImageUpload.files.length; i++) {
		detailFile.push([generateRandomString(10) + "_" + productImageUpload.files[i].name, productImageUpload.files[i]]);
	}
	
	textBefore = productDetail.value.substring(0, cursorPosition);
	textAfter = productDetail.value.substring(cursorPosition);
	console.log(detailFile);
	for (let i = 0; i <  productImageUpload.files.length; i++) {
		productDetail.value = textBefore + "(img){" + detailFile[productImageUpload.files.length - i - 1][0]  + "}" + "\n" + textAfter;
		textBefore = productDetail.value.substring(0, cursorPosition);
		textAfter = productDetail.value.substring(cursorPosition);
	}
}

function onChangeUpdateProduct() {
	product_name2.value = productOptionList2[productOptionList2.selectedIndex].dataset.name;
	product_price2.value = productOptionList2[productOptionList2.selectedIndex].dataset.price;
	stock_level2.value = productOptionList2[productOptionList2.selectedIndex].dataset.stock;
	product_description2.value = productOptionList2[productOptionList2.selectedIndex].dataset.description;
	parentCategorie2.selectedIndex = findIndex((productOptionList2[productOptionList2.selectedIndex].dataset.category));
}

function updateProduct() {
	const url = address + 'adminUpdateProduct';

	let formData = new FormData();
	formData.append("admin", userId);
	formData.append("product_id", productOptionList2[productOptionList2.selectedIndex].id);
	formData.append("product_name", product_name2.value);
	formData.append("product_price", product_price2.value);
	formData.append("product_description", product_description2.value);
	formData.append("categories_id", parentCategorie2[parentCategorie2.selectedIndex].id);
	formData.append("stock_level", stock_level2.value);
	// Send the POST request
	fetch(url, {
	  method: 'POST',   
	  body: formData       // Convert the data to a JSON string
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		if (result.includes("successfully")) {
			alert("Update product successfully");
			window.location.reload();
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
	  });
}

function findIndex(idIndex) {
	for (let i = 0; i < parentCategorie2.length; i++) {
		if (parentCategorie2[i].id == idIndex) {
			return i;
		}
	}
}