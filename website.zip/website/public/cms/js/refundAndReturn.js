const refundSelection = document.getElementById("refundSelection");
const refundOrderItemId = document.getElementById("refundOrderItemId");
const refundPrice = document.getElementById("refundPrice");
const refundReason = document.getElementById("refundReason");
const requestDate = document.getElementById("requestDate");
const refundStatus = document.getElementById("refundStatus");
const returnStatus = document.getElementById("returnStatus");

function confirmRequestClick() {
	const url = address + 'updateRefundAndReturn';
	let formData = new FormData();
	formData.append("admin", userId);
	formData.append("refundId", refundSelection[refundSelection.selectedIndex].dataset.refund_id);
	formData.append("refundStatus", refundStatus[refundStatus.selectedIndex].value);
	formData.append("returnId", refundSelection[refundSelection.selectedIndex].dataset.return_item_id);
	formData.append("returnStatus", returnStatus[returnStatus.selectedIndex].value);
	
	fetch(url, {
	method: 'POST',
	body: formData,
	})
	.then(response => response.text())
	.then(result => {
		if (result.includes("successfully")) {
			alert("Request update successfully");
			window.location.reload();
		}
	});
}

function getRefundRequest() {
	const url = address + 'getRefundRequest';
	
	fetch(url, {
	method: 'POST',
	})
	.then(response => response.text())
	.then(result => {
		refundSelection.innerHTML = result;
		onChangeForm();
	});
}

function onChangeForm() {
	refundOrderItemId.value = refundSelection[refundSelection.selectedIndex].dataset.order_item_id;
	refundPrice.value = refundSelection[refundSelection.selectedIndex].dataset.amount;
	refundReason.value = refundSelection[refundSelection.selectedIndex].dataset.reason;
	requestDate.value = refundSelection[refundSelection.selectedIndex].dataset.request_date;
	refundStatus.selectedIndex = findRefundStatus(refundSelection[refundSelection.selectedIndex].dataset.refund_status);
	returnStatus.selectedIndex = findReturnStatus(refundSelection[refundSelection.selectedIndex].dataset.return_status);
	
	if (refundSelection[refundSelection.selectedIndex].dataset.return_item_id == "null") {
		returnStatus.disabled = true;
	}
	else {
		returnStatus.disabled = false;
	}
}

getRefundRequest();

function findRefundStatus(index) {
	for (let i = 0; i < refundStatus.length; i++) {
		if (refundStatus[i].value == index) {
			return i;
		}
	}
}
function findReturnStatus(index) {
	for (let i = 0; i < returnStatus.length; i++) {
		if (returnStatus[i].value == index) {
			return i;
		}
	}
	return returnStatus.length - 1;
}