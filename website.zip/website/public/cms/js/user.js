const userSelection = document.getElementById("userSelection");
const userSelection2 = document.getElementById("userSelection2");

const userEmail = document.getElementById("userEmail");
const userPassword = document.getElementById("userPassword");
const userConfirmPassword = document.getElementById("userConfirmPassword");
const userStatusSelection = document.getElementById("userStatusSelection");
const userSecuityQuestionSelection = document.getElementById("userSecuityQuestionSelection");
const userSecuityQuestionAnswer = document.getElementById("userSecuityQuestionAnswer");

const userEmail2 = document.getElementById("userEmail2");
const userPassword2 = document.getElementById("userPassword2");
const userConfirmPassword2 = document.getElementById("userConfirmPassword2");
const userStatusSelection2 = document.getElementById("userStatusSelection2");
const userSecuityQuestionSelection2 = document.getElementById("userSecuityQuestionSelection2");
const userSecuityQuestionAnswer2 = document.getElementById("userSecuityQuestionAnswer2");

function createUser() {
	
	if (userPassword.value != userConfirmPassword.value) {
		alert("User password not match!");
		return;
	}
	if (userPassword.length < 8) {
		alert("User password too short!");
		return;
	}
	const url = address + 'createUser';
	let formData = new FormData();
	formData.append("admin", userId);
	formData.append("userEmail", userEmail.value.trim());
	formData.append("userPassword", userPassword.value.trim());
	formData.append("userStatusSelection", userStatusSelection[userStatusSelection.selectedIndex].value);
	formData.append("userSecuityQuestionSelection", userSecuityQuestionSelection[userSecuityQuestionSelection.selectedIndex].id);
	formData.append("userSecuityQuestionAnswer", userSecuityQuestionAnswer.value);
	fetch(url, {
		method: 'POST',
		body: formData,
	})
	.then(response => {
		return response.text();
	})
	.then(result => {
		if (result.includes("successfully")) {
			alert("User create successfully");
			window.location.reload();
		}
	})
	.catch(error => {
		alert(error);
	});
}

function deleteUser() {
	const url = address + 'deleteUser';
	let formData = new FormData();
	formData.append("admin", userId);
	formData.append("userId", userSelection.options[userSelection.selectedIndex].dataset.user_id);
	fetch(url, {
		method: 'POST',
		body: formData,
	})
	.then(response => {
		return response.text();
	})
	.then(result => {
		if (result.includes("successfully")) {
			alert("User delete successfully");
			window.location.reload();
		}
	})
	.catch(error => {
		alert(error);
	});
}

function getSecuityQuestionSelection() {
	const url = address + 'getSecureityQuestion';
	fetch(url, {
		method: 'POST',
	})
	.then(response => {
		
		if (response.status == 400) {
			alert(response.text());
			return;
		}
		
		return response.text();
	})
	.then(result => {
			userSecuityQuestionSelection.innerHTML = result;
			userSecuityQuestionSelection2.innerHTML = result;
	})
	.catch(error => {
		alert(error);
	});
}

function getUser() {
	const url = address + 'getUser';
	fetch(url, {
		method: 'POST',
	})
	.then(response => {
		
		if (response.status == 200) {
			return response.text();
		}
		else 
			alert(response.text());
			return;
	})
	.then(result => {
		if (result != "") {
			userSelection.innerHTML = result;
			userSelection2.innerHTML = result;
			onChangeUserDate();
		}
	})
	.catch(error => {
		alert(error);
	});
}

function onChangeUserDate() {
	userEmail2.value = findOption(userSelection2.selectedIndex).dataset.email;
	userPassword2.value = findOption(userSelection2.selectedIndex).dataset.password;
	userConfirmPassword2.value = findOption(userSelection2.selectedIndex).dataset.password;
	userStatusSelection2.selectedIndex = findOption(userSelection2.selectedIndex).dataset.status_id;
	userSecuityQuestionSelection2.selectedIndex = findSecurityOption(userSelection2.options[userSelection2.selectedIndex].dataset.secuity_question_id);
	userSecuityQuestionAnswer2.value = findOption(userSelection2.selectedIndex).dataset.secuity_question_answer;
}

function findOption(id) {
	for (let i = 0; i < userSelection2.options.length; i++) {
		if (userSelection2.options[i].id == id) {
			return userSelection2.options[i];
		}
	}
	return null;
}

function findSecurityOption(id) {
	for (let i = 0; i < userSecuityQuestionSelection2.options.length; i++) {
		if (userSecuityQuestionSelection2.options[i].id == id) {
			return i;
		}
	}
	return null;
}


function updateUser() {
	
	if (userPassword2.value != userConfirmPassword2.value) {
		alert("User password not match!");
		return;
	}
	if (userPassword2.length < 8) {
		alert("User password too short!");
		return;
	}
	const url = address + 'updateUser';
	let formData = new FormData();
	formData.append("admin", userId);
	formData.append("userId", findOption(userSelection2.selectedIndex).dataset.user_id);
	formData.append("userEmail", userEmail2.value.trim());
	formData.append("userPassword", userPassword2.value.trim());
	formData.append("userStatusSelection", userStatusSelection2[userStatusSelection2.selectedIndex].value);
	formData.append("userSecuityQuestionSelection", userSecuityQuestionSelection2[userSecuityQuestionSelection2.selectedIndex].id);
	formData.append("userSecuityQuestionAnswer", userSecuityQuestionAnswer2.value);
	fetch(url, {
		method: 'POST',
		body: formData,
	})
	.then(response => {
		return response.text();
	})
	.then(result => {
		if (result.includes("successfully")) {
			alert("User update successfully");
			window.location.reload();
		}
	})
	.catch(error => {
		alert(error);
	});
}

getSecuityQuestionSelection();
getUser();