const carouselImageUpload = document.getElementById("carouselImageUpload");
const carouselTitle = document.getElementById("carouselTitle");
const carouseldescription = document.getElementById("carouseldescription");
const carouselButtonName = document.getElementById("carouselButtonName");

function createCarousel(event) {
	event.preventDefault();

	if (!carouselImageUpload.files || !carouselTitle.value || !carouseldescription.value || !userId) {
		alert("Please provide the full body");
		return;
	}
	const url = address + 'create_carouselImage';
	let formData = new FormData();
	formData.append("admin", userId);
	formData.append("image_title", carouselTitle.value);
	formData.append("image_content", carouseldescription.value);
	formData.append("carouselButtonName", carouselButtonName.value);
	formData.append("carouselImageUpload", carouselImageUpload.files[0]);
	
	// Send the POST request
	fetch(url, {
	  method: 'POST',
	  body: formData, // No need for JSON.stringify when using FormData
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		if (result.includes("successfully")) {
			alert("Carousel image created successfully");
			window.location.reload();
		}
		else {
			alert("Please provide the full body");
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
	  });
}

function getCarousel() {	
	const url = address + 'get_carouselImage';
	
	// Send the POST request
	fetch(url, {
	  method: 'POST',
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
			document.getElementById("carouselImage").innerHTML = result;
			onImageChange();
	  })
	  .catch(error => {
		console.error('Error:', error);
	  });
}

function deleteCarouselImage() {	
	const url = address + 'delete_carouselImage';
	
	let formData = new FormData();
	formData.append("admin", userId);
	formData.append("carouselImageId", carouselImage[carouselImage.selectedIndex].id);
	
	// Send the POST request
	fetch(url, {
	  method: 'POST',
	  body: formData, // No need for JSON.stringify when using FormData
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
			if (result.includes("successfully"))
			alert("Delete carousel image successfully");
				window.location.reload();
	  })
	  .catch(error => {
		console.error('Error:', error);
	  });
}

function onImageChange() {
	document.getElementById("carouselImageView").src = document.getElementById("carouselImage")[document.getElementById("carouselImage").selectedIndex].dataset.image_path;
}
getCarousel();