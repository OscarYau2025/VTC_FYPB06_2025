const productSelection = document.getElementById("productSelection");
const reviewSelection = document.getElementById("reviewSelection");
const statusSelection = document.getElementById("statusSelection");
const author = document.getElementById("author");
const reviewContent = document.getElementById("reviewContent");
const modifyCount = document.getElementById("modifyCount");
const createDate = document.getElementById("createDate");
const lastUpdateDate = document.getElementById("lastUpdateDate");

let oldContent = "";

function updateReviewStatus() {
	const url = address + 'updateReviewStatus';

	let formData = new FormData();
	formData.append("admin", userId);
	formData.append("review", reviewSelection[reviewSelection.selectedIndex].id);
	formData.append("reviewContent", reviewContent.value);
	formData.append("reviewStatus", statusSelection[statusSelection.selectedIndex].value);
	formData.append("modifyCount", parseInt(modifyCount.value) + 1);
	formData.append("oldContent", oldContent);
	formData.append("user_id", author.value);

	fetch(url, {
	  method: 'POST',
	  body: formData, // No need for JSON.stringify when using FormData
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		console.log(result);
		if (result != "") {
			alert("Review update successfully");
			window.location.reload(true);
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
    });
}

function deleteReview() {
	const url = address + 'deleteReview';

	let formData = new FormData();
	formData.append("admin", userId);
	formData.append("review", reviewSelection[reviewSelection.selectedIndex].id);
	formData.append("oldContent", oldContent);
	formData.append("user_id", author.value);

	fetch(url, {
	  method: 'POST',
	  body: formData, // No need for JSON.stringify when using FormData
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		console.log(result);
		if (result != "") {
			alert("Review delete successfully");
			window.location.reload(true);
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
    });
}

function getProduct() {
	
	const url = address + 'reviewManagerGetProduct';

	fetch(url, {
	  method: 'POST',
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		if (result != "") {
			productSelection.innerHTML = result;
			productSelection2.innerHTML = result;
			getReview();
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
	});
}

function getReview() {
	const url = address + 'reviewManagerGetReview';

	let formData = new FormData();
	formData.append("product", productSelection[productSelection.selectedIndex].id);

	fetch(url, {
	  method: 'POST',
	  body: formData, // No need for JSON.stringify when using FormData
	})
	  .then(response => response.text()) // Handle the response as text
	  .then(result => {
		if (result != "") {
			reviewSelection.innerHTML = result;
			reviewSelection2.innerHTML = result;
			setReviewProperties();
		}
	  })
	  .catch(error => {
		console.error('Error:', error);
	});
}

function setReviewProperties() {
	author.value = reviewSelection[reviewSelection.selectedIndex].dataset.author;
	reviewContent.value = reviewSelection[reviewSelection.selectedIndex].dataset.content;
	modifyCount.value = reviewSelection[reviewSelection.selectedIndex].dataset.modify_count;
	createDate.value = reviewSelection[reviewSelection.selectedIndex].dataset.create_at;
	lastUpdateDate.value = reviewSelection[reviewSelection.selectedIndex].dataset.last_update;
	statusSelection.selectedIndex = findStatusSelectionIndex(reviewSelection[reviewSelection.selectedIndex].dataset.status);
	
	oldContent = reviewContent.value;
}

function findStatusSelectionIndex(index) {
	for (let i = 0; i < statusSelection.length; i++) {
		if (statusSelection[i].value == index) {
			return i;
		}
	}
	return null;
}

getProduct();